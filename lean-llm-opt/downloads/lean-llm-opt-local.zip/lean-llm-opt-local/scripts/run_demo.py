#!/usr/bin/env python3
"""Start the local demo with an isolated Python environment and Docker worker."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys
import time
import threading
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".venv-demo"


def main():
    parser = argparse.ArgumentParser(description="Start LEAN-LLM-OPT at http://127.0.0.1:8097/demo/")
    parser.add_argument("--port", type=int, default=8097)
    parser.add_argument("--skip-build", action="store_true", help="Start API without building the Docker image")
    parser.add_argument("--rebuild", action="store_true", help="Rebuild the isolated solver image")
    parser.add_argument("--open", dest="open_browser", action="store_true", help="Open the local workbench after the server is ready")
    args = parser.parse_args()
    python = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if Path(sys.prefix).resolve() != VENV.resolve():
        if not python.exists():
            subprocess.run([sys.executable, "-m", "venv", str(VENV)], check=True)
        if not (VENV / ".demo-dependencies-ready").exists():
            subprocess.run([str(python), "-m", "pip", "install", "-r", str(ROOT / "demo_backend/requirements.txt")], check=True)
            (VENV / ".demo-dependencies-ready").touch()
        os.execv(str(python), [str(python), str(Path(__file__).resolve()), *sys.argv[1:]])
    docker = shutil.which("docker")
    if docker and not args.skip_build:
        def docker_ready():
            try:
                return subprocess.run([docker, "info"], capture_output=True, timeout=8).returncode == 0
            except (OSError, subprocess.TimeoutExpired):
                return False
        if not docker_ready() and sys.platform == "darwin" and Path("/Applications/Docker.app").exists():
            print("Starting Docker Desktop…", flush=True)
            subprocess.run(["open", "-a", "Docker"], check=False)
            deadline = time.monotonic() + 60
            while time.monotonic() < deadline and not docker_ready():
                time.sleep(2)
        if docker_ready():
            image_exists = subprocess.run([docker, "image", "inspect", "lean-llm-opt-demo:local"], capture_output=True).returncode == 0
            if args.rebuild or not image_exists:
                print("Building the isolated solver image (no license or API key is copied)…", flush=True)
                result = subprocess.run([docker, "build", "-t", "lean-llm-opt-demo:local", "-f", "demo_backend/Dockerfile", "."], cwd=ROOT)
                if result.returncode:
                    print("Solver image unavailable. The API will still support explanation and code generation.", flush=True)
        else:
            print("Docker is unavailable. Isolated execution will be shown as unavailable.", flush=True)
    sys.path.insert(0, str(ROOT))
    import uvicorn
    from demo_backend.api import create_app
    url = f"http://127.0.0.1:{args.port}/demo/"
    print(f"Local demo: {url}", flush=True)
    server = uvicorn.Server(uvicorn.Config(create_app(), host="127.0.0.1", port=args.port, access_log=False))
    if args.open_browser:
        def open_when_ready():
            deadline = time.monotonic() + 30
            while not server.started and not server.should_exit and time.monotonic() < deadline:
                time.sleep(0.1)
            if server.started and not server.should_exit:
                webbrowser.open(url)
        threading.Thread(target=open_when_ready, name="lean-open-browser", daemon=True).start()
    server.run()


if __name__ == "__main__":
    main()
