const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const params=new URLSearchParams(location.search), API='/api/demo';
const PUBLIC_HOME='https://adamleopold.github.io/AdamLu.github.io/lean-llm-opt/';
const LOCAL_WORKSPACE='http://127.0.0.1:8097/demo/';
const EXAMPLE_IDS=new Set(['tp','nrm','ra','flp','ap']);
const isLocalRuntime=['127.0.0.1','localhost','[::1]','::1'].includes(location.hostname)&&document.documentElement.dataset.deployment!=='static';
const terminal=new Set(['completed','failed','cancelled','timeout']);
const stages={classification:['问题分类','Classification'],workflow:['工作流生成','Workflow'],data:['数据读取','Data access'],model:['数学建模','Formulation'],code:['代码生成','Code generation'],execution:['求解','Solve'],output:['输出','Output']};
const statuses={queued:['排队中','Queued'],running:['运行中','Running'],started:['进行中','Working'],completed:['已完成','Completed'],failed:['失败','Failed'],error:['错误','Error'],cancelled:['已取消','Cancelled'],timeout:['超时','Timed out'],optimal:['已证最优','Optimal'],infeasible:['不可行','Infeasible'],unbounded:['无界','Unbounded'],time_limit:['达到时间上限','Time limit'],solver_stopped:['已停止，未证最优','Stopped; not proven optimal'],execution_unavailable:['执行环境不可用','Execution unavailable'],cancellation_requested:['正在停止','Stopping'],saved:['历史记录','Saved']};
const state={lang:document.documentElement.dataset.lang,theme:document.documentElement.dataset.theme,session:null,runs:new Map(),selectedRun:null,activeRun:null,source:null,tab:'model',connected:false,health:null,lastSeq:new Map(),processNodes:new Map(),stageNodes:new Map(),downloadUrl:null,initializing:true,sending:false,capabilities:null,setupConfirmed:false,setupBusy:false,setupError:'',exampleLoading:false,catalog:[],previewFiles:[],previewMode:false,pendingExample:null,pendingSend:false,runtimeChecked:false,examplesCollapsed:false,artifactTrigger:null};
const welcomeTemplate=$('#welcome').cloneNode(true),t=(zh,en)=>state.lang==='en'?en:zh,local=v=>v&&typeof v==='object'?(v[state.lang]||v.en||v.zh):v;
const label=k=>statuses[k]?t(...statuses[k]):k;
function node(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=String(text);return e;}
function store(k,v){try{localStorage.setItem(k,v);}catch{}}
function read(k){try{return localStorage.getItem(k);}catch{return null;}}
function createRunChannel(){try{return typeof BroadcastChannel==='function'?new BroadcastChannel('lean-demo-events'):null;}catch{return null;}}
let runChannel=createRunChannel();
function publishRunEvent(event){
 const secret=$('#api-key').value;
 const clean=value=>{if(typeof value==='string')return secret?value.replaceAll(secret,'[redacted]'):value;if(Array.isArray(value))return value.map(clean);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([key])=>!['api_key','authorization','password','secret'].includes(key.toLowerCase())).map(([key,item])=>[key,clean(item)]));return value;};
 runChannel?.postMessage({type:'lean:run',event:clean(event)});
}
function publishSession(id){runChannel?.postMessage({type:'lean:session',id});}
function toast(text){$('#toast').textContent=text;$('#toast').classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').classList.remove('visible'),2800);}
function notice(text=''){$('#error-notice').textContent=text;$('#error-notice').hidden=!text;}
function nearBottom(){const e=$('#conversation');return e.scrollHeight-e.scrollTop-e.clientHeight<130;}
function scrollBottom(force=false){if(force||nearBottom())requestAnimationFrame(()=>{$('#conversation').scrollTop=$('#conversation').scrollHeight;});}
function translate(root=document){$$('[data-zh][data-en]',root).forEach(e=>{e.textContent=e.getAttribute(`data-${state.lang}`);});}
function researchHome(){const u=isLocalRuntime?new URL(PUBLIC_HOME):new URL('../',location.href);u.searchParams.set('lang',state.lang);u.searchParams.set('theme',state.theme);$('#research-home').href=u.href;$('.studio-brand').href=u.href;}
function preferences(lang,theme,persist=false){
 state.lang=lang==='en'?'en':'zh';state.theme=theme==='light'?'light':'dark';document.documentElement.dataset.lang=state.lang;document.documentElement.dataset.theme=state.theme;document.documentElement.lang=state.lang==='en'?'en':'zh-CN';
 document.title=`LEAN-LLM-OPT · ${t('建模工作台','Modeling Studio')}`;translate();$('#language-toggle').textContent=state.lang==='en'?'中':'EN';$('#query').placeholder=t('描述目标、变量与约束；也可以追问或修改已有模型…','Describe the goal, decisions and constraints, or explain and revise the model…');
 if(persist){store('lean-lang',state.lang);store('lean-theme',state.theme);}renderHealth();renderFiles();renderVersions();renderConversation();renderArtifact();researchHome();updateSetup();
}
async function api(path,options={}){
 if(!isLocalRuntime)throw new Error(t('请在这台电脑的本机工作台运行。','Open the local workspace on this computer to run.'));
 const response=await fetch(API+path,{credentials:'same-origin',...options,headers:options.body instanceof FormData?options.headers:{'Content-Type':'application/json',...options.headers}});let data;
 try{data=await response.json();}catch{throw new Error(t('无法连接建模服务，请稍后重试。','Cannot connect to the modeling service. Try again later.'));}
 if(!response.ok)throw new Error(typeof data.detail==='string'?data.detail:t('请求失败，请重试。','The request failed. Please try again.'));return data;
}
function busy(id){
 state.activeRun=id;const working=Boolean(id)||state.sending||state.exampleLoading;document.body.classList.toggle('busy',working);$('#cancel-button').hidden=!id;$('#cancel-button').disabled=false;$('#send-button').hidden=Boolean(id);$('#send-button').disabled=working;
 for(const selector of ['#new-session','#provider','#model','#api-key'])$(selector).disabled=working;
 for(const selector of ['#upload-button','#file-input','#drop-zone'])$(selector).disabled=working||!state.session||!state.setupConfirmed;
 $$('.file-remove,[data-example]').forEach(e=>{e.disabled=working;});$('#runtime-check').disabled=working||!isLocalRuntime||!state.connected;
}
function renderHealth(){
 const e=$('#connection-state');e.classList.toggle('online',state.connected&&state.setupConfirmed);e.classList.toggle('offline',isLocalRuntime&&!state.connected&&!state.initializing);
 $('span',e).textContent=!isLocalRuntime?t('在你的电脑运行','Run on your computer'):state.initializing?t('检查本机连接','Checking local connection'):state.connected?t('本机服务已连接','Local service connected'):t('本机服务未连接','Local service offline');
 const ready=Boolean(state.health?.execution_available);$('#runtime-dot').style.background=state.runtimeChecked?(ready?'var(--success)':'var(--error)'):'var(--dim)';
 $('#runtime-title').textContent=state.runtimeChecked?(ready?t('求解器就绪','Solver ready'):t('执行环境待配置','Execution setup needed')):t('Python / Gurobi · 本机执行','Python / Gurobi · local');
 $('#runtime-description').textContent=state.runtimeChecked?(ready?t('生成程序将在本机隔离运行。','Generated programs run locally in isolation.'):t('可继续查看模型与代码。','Formulations and code remain available.')):isLocalRuntime?t('运行任务时检测执行环境，也可手动检测。','Checked when running a task; a manual check is also available.'):t('启动本机工作台后运行程序。','Start the local workspace to run programs.');
 $('#query').readOnly=!isLocalRuntime;$('#query').placeholder=isLocalRuntime?t('描述目标、变量与约束；也可以追问或修改已有模型…','Describe the goal, decisions and constraints, or revise an existing model…'):t('选择示例预览问题与数据，打开本机工作台后运行。','Preview an example, then open the local workspace to run it.');
 $('#key-field').hidden=!isLocalRuntime||$('#provider').value!=='openai';
 $('#model-location').textContent=$('#provider').value==='openai'?t('模型请求发送至 OpenAI，产物由本机工作台保存。','Model requests go to OpenAI; artifacts are saved by the local workspace.'):$('#provider').value==='ollama'?t('GPT-OSS 通过这台电脑的 Ollama 运行。','GPT-OSS uses Ollama on this computer.'):t('选择模型服务，查看安装与连接方式。','Choose a model service to view its setup instructions.');
}
async function health(){
 if(!isLocalRuntime){state.initializing=false;state.connected=false;renderHealth();busy(state.activeRun);return;}
 try{const cap=await api('/capabilities');if(cap.service!=='lean-local-companion'||cap.protocol!==1)throw new Error('Incompatible local service');state.capabilities=cap;state.connected=true;}catch{state.capabilities=null;state.connected=false;}
 state.initializing=false;renderHealth();busy(state.activeRun);
}
function localWorkspaceURL(exampleId=null,provider=$('#provider').value){
 const u=new URL(LOCAL_WORKSPACE);u.searchParams.set('lang',state.lang);u.searchParams.set('theme',state.theme);u.searchParams.set('provider',provider==='openai'?'openai':'ollama');
 if(EXAMPLE_IDS.has(exampleId)){u.searchParams.set('example',exampleId);u.searchParams.set('autorun','1');}return u.href;
}
function selectedExample(){return state.catalog.find(e=>e.id===state.pendingExample);}
function updateSetup(){
 const openai=$('#provider').value==='openai';$('#setup-title').textContent=openai?t('使用你自己的 OpenAI Key','Use your OpenAI key'):t('连接这台电脑的 GPT-OSS','Connect GPT-OSS on this computer');
 $('#setup-summary').textContent=openai?t('模型请求从你的电脑发往 OpenAI。API Key 请在本机工作台中输入。','Model requests go from your computer to OpenAI. Enter your API key in the local workspace.'):t('GPT-OSS 通过你的电脑上的 Ollama 运行。完成首次准备后，本机工作台会自动使用本机模型。','GPT-OSS runs through Ollama on your computer. After setup, the local workspace uses that computer’s model automatically.');
 $('#setup-provider-ollama').setAttribute('aria-pressed',String(!openai));$('#setup-provider-openai').setAttribute('aria-pressed',String(openai));$('#setup-ollama').hidden=openai;$('#setup-openai').hidden=!openai;$('#setup-public').hidden=isLocalRuntime;$('#setup-key-field').hidden=!openai||!isLocalRuntime;$('#setup-detect').hidden=!isLocalRuntime;
 const chosen=selectedExample();$('#setup-example').hidden=!chosen;$('#setup-example').textContent=chosen?`${chosen.id.toUpperCase()} · ${local(chosen.title)} · ${local(chosen.dimensions)}`:'';
 const status=$('#setup-status');status.dataset.ready='false';status.dataset.error='false';
 if(!isLocalRuntime)status.textContent=openai?t('启动运行包后，在本机工作台输入自己的 Key。模型调用 OpenAI，Python 在本机执行。','Start the runtime package and enter your key in the local workspace. OpenAI runs the model; Python runs locally.'):t('启动运行包后，打开这台电脑的工作台。模型与 Python 都在这台电脑运行。','Start the runtime package, then open this computer’s workspace. The model and Python run on this computer.');
 else if(state.initializing)status.textContent=t('正在读取本机服务状态…','Reading local service status…');
 else if(!state.connected){status.textContent=t('未连接到本机服务。请在运行包目录启动 scripts/run_demo.py 后重新检测。','Local service unavailable. Start scripts/run_demo.py in the runtime folder and check again.');status.dataset.error='true';}
 else if(openai){status.textContent=t('已连接本机工作台。输入自己的 API Key 后即可继续。','The local workspace is connected. Enter your API key to continue.');status.dataset.ready='true';}
 else if(state.capabilities?.ollama?.ready){status.textContent=t('已检测到本机 gpt-oss:20b 和 nomic-embed-text。','Local gpt-oss:20b and nomic-embed-text are ready.');status.dataset.ready='true';}
 else{const models=state.capabilities?.ollama?.missing_models||['gpt-oss:20b','nomic-embed-text'];status.textContent=(state.capabilities?.ollama?.reachable?t('待下载模型：','Models to download: '):t('请打开本机 Ollama，并下载：','Open Ollama on this computer and download: '))+models.join(' · ');status.dataset.error='true';}
 $('#setup-confirm').textContent=!isLocalRuntime?(chosen?t('在本机打开此示例 ↗','Open this example locally ↗'):t('打开本机工作台 ↗','Open the local workspace ↗')):chosen?t('使用本机服务运行此示例','Run this example locally'):t('连接并开始建模','Connect and start modeling');
 if(state.setupError){status.textContent=state.setupError;status.dataset.ready='false';status.dataset.error='true';}
 $('#setup-confirm').disabled=state.setupBusy;$('#setup-detect').disabled=state.setupBusy;
}
function openSetup(exampleId=state.pendingExample){
 state.setupError='';if(!$('#provider').value){$('#provider').value='ollama';$('#model').value='gpt-oss:20b';$('#model').readOnly=true;}
 if(EXAMPLE_IDS.has(exampleId))state.pendingExample=exampleId;closeSettings(false);updateSetup();if(!$('#local-setup').open)$('#local-setup').showModal();
}
async function confirmSetup(){
 if(state.setupBusy)return;if(state.activeRun){$('#setup-status').textContent=t('当前任务正在运行，完成后可更改连接设置。','Wait for the current run before changing the connection.');return;}
 if(!isLocalRuntime){location.assign(localWorkspaceURL(state.pendingExample));return;}
 state.setupBusy=true;state.setupError='';updateSetup();
 try{
  await health();if(!state.connected)return;
  if($('#provider').value==='ollama'&&!state.capabilities?.ollama?.ready){updateSetup();return;}
  if($('#provider').value==='openai'){const key=$('#setup-api-key').value.trim()||$('#api-key').value.trim();if(!key){state.setupError=t('请输入你的 OpenAI API Key。','Enter your OpenAI API key.');$('#setup-status').textContent=state.setupError;$('#setup-api-key').focus();return;}$('#api-key').value=key;$('#setup-api-key').value='';}
  if(!state.session){const saved=params.get('session')||read('lean-demo-session');try{await openSession(saved||undefined);}catch{await openSession();}}
  state.setupConfirmed=true;$('#local-setup').close();renderHealth();busy(state.activeRun);const id=state.pendingExample;state.pendingExample=null;
  const shouldSend=state.pendingSend;state.pendingSend=false;if(id)await example(id);else if(shouldSend){await send();}else $('#query').focus();
 }catch(error){state.setupError=error.message;$('#setup-status').textContent=error.message;$('#setup-status').dataset.error='true';}
 finally{state.setupBusy=false;updateSetup();}
}
async function checkRuntime(){
 if(!isLocalRuntime){openSetup();return;}if(!state.connected||state.activeRun)return;$('#runtime-check').disabled=true;$('#runtime-description').textContent=t('正在检测本机 Python / Gurobi…','Checking local Python / Gurobi…');
 try{state.health=await api('/runtime/check',{method:'POST'});state.runtimeChecked=true;}catch(error){notice(error.message);}finally{renderHealth();busy(state.activeRun);}
}
async function loadCatalog(){
 const response=await fetch(new URL('examples.json',import.meta.url));if(!response.ok)throw new Error(t('无法载入示例目录，请刷新。','Could not load the example catalog. Refresh to retry.'));
 const data=await response.json();if(data.schema_version!==1||data.examples?.length!==5||new Set(data.examples.map(e=>e.id)).size!==5||data.examples.some(e=>!EXAMPLE_IDS.has(e.id)))throw new Error('Invalid example catalog');state.catalog=data.examples;renderExampleCards();
}
function renderExampleCards(){
 const paths={tp:'M3 5h11v11H3z M14 9h4l3 4v3h-7 M5 16a2 2 0 1 0 4 0 M15 16a2 2 0 1 0 4 0',nrm:'M4 4v16h16 M8 14l4-5 4 2 4-6 M16 5h4v4',ra:'M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M14 14h6v6h-6z',flp:'M4 21V9l8-5 8 5v12 M8 21v-7h8v7 M8 10h0 M16 10h0',ap:'M9 6h12 M9 12h12 M9 18h12 M3 6l1 1 2-3 M3 12l1 1 2-3 M3 18l1 1 2-3'};
 for(const grid of $$('.example-grid')){if(!state.catalog.length)continue;grid.replaceChildren();for(const e of state.catalog){const card=node('button','example-card'),top=node('span','example-card-top'),badge=node('span','example-card-badge'),icon=document.createElementNS('http://www.w3.org/2000/svg','svg'),path=document.createElementNS('http://www.w3.org/2000/svg','path');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('aria-hidden','true');path.setAttribute('d',paths[e.id]);icon.append(path);badge.append(icon,node('b','',e.id.toUpperCase()));card.type='button';card.dataset.example=e.id;card.setAttribute('aria-pressed',String(e.id===state.pendingExample));top.append(badge,node('span','','↗'));card.append(top,node('strong','',local(e.title)),node('small','',local(e.dimensions)),node('span','example-card-description',local(e.description)),node('span','example-card-action',t('运行此示例','Run example')));grid.append(card);}}
}

// Construct Markdown from text nodes. Raw HTML from users or models is never inserted.
function inline(e,text){for(const p of text.split(/(`[^`\n]+`|\*\*[^*\n]+\*\*)/g)){if(p.startsWith('`')&&p.endsWith('`'))e.append(node('code','',p.slice(1,-1)));else if(p.startsWith('**')&&p.endsWith('**'))e.append(node('strong','',p.slice(2,-2)));else e.append(document.createTextNode(p));}}
function pipeCells(line){
 const cells=[];let cell='',delimiters=0;line=line.trim();
 for(let i=0;i<line.length;i++){
  const character=line[i];
  if(character==='\\'&&line[i+1]==='\\'){cell+='\\\\';i++;}
  else if(character==='\\'&&line[i+1]==='|'){cell+='|';i++;}
  else if(character==='|'){cells.push(cell.trim());cell='';delimiters++;}
  else cell+=character;
 }
 if(!delimiters)return null;
 cells.push(cell.trim());
 if(line.startsWith('|')&&cells[0]==='')cells.shift();
 if(cells.at(-1)==='')cells.pop();
 return cells;
}
function pipeTable(headers,separators,rows){
 const scroll=node('div','markdown-table-scroll');scroll.tabIndex=0;scroll.setAttribute('role','region');scroll.setAttribute('aria-label',t('可滚动数据表','Scrollable data table'));
 const table=node('table','result-table markdown-table'),head=node('thead'),heading=node('tr'),body=node('tbody');
 const alignment=separators.map(value=>value.startsWith(':')&&value.endsWith(':')?'center':value.endsWith(':')?'right':'left');
 headers.forEach((text,index)=>{const th=node('th');th.scope='col';th.style.textAlign=alignment[index];inline(th,text);heading.append(th);});
 for(const values of rows){const row=node('tr');for(let index=0;index<Math.max(headers.length,values.length);index++){const td=node('td');td.style.textAlign=alignment[index]||'left';inline(td,values[index]||'');row.append(td);}body.append(row);}
 head.append(heading);table.append(head,body);scroll.append(table);return scroll;
}
function markdown(text=''){
 const root=node('div','markdown'),lines=String(text).split('\n');let paragraph=[],list=null;const flush=()=>{if(paragraph.length){const p=node('p');inline(p,paragraph.join('\n'));root.append(p);paragraph=[];}list=null;};
 for(let i=0;i<lines.length;i++){const line=lines[i];if(/^\s*```/.test(line)){flush();const code=[];while(++i<lines.length&&!/^\s*```/.test(lines[i]))code.push(lines[i]);const pre=node('pre');pre.append(node('code','',code.join('\n')));root.append(pre);continue;}
  if(/^\s*(\$\$|\\\[)/.test(line)){flush();const math=[line],close=line.trim().startsWith('$$')?'$$':'\\]';if(!(line.trim().endsWith(close)&&line.trim().length>close.length)){while(++i<lines.length){math.push(lines[i]);if(lines[i].includes(close))break;}}root.append(node('div','math-source',math.join('\n')));continue;}
  const headers=pipeCells(line),separators=i+1<lines.length?pipeCells(lines[i+1]):null;
  if(headers?.length&&separators?.length===headers.length&&separators.every(value=>/^:?-{3,}:?$/.test(value))){flush();const rows=[];let next=i+2;for(;next<lines.length;next++){const values=pipeCells(lines[next]);if(!values)break;rows.push(values);}root.append(pipeTable(headers,separators,rows));i=next-1;continue;}
  const heading=line.match(/^\s*#{1,6}\s+(.+)/);if(heading){flush();const h=node('h3');inline(h,heading[1]);root.append(h);continue;}
  const item=line.match(/^\s*(?:[-*]|\d+\.)\s+(.+)/);if(item){if(paragraph.length)flush();if(!list){list=node(/^\s*\d+\./.test(line)?'ol':'ul');root.append(list);}const li=node('li');inline(li,item[1]);list.append(li);continue;}
  if(!line.trim()){flush();continue;}list=null;paragraph.push(line);
 }flush();return root;
}
function math(element){if(window.renderMathInElement)try{window.renderMathInElement(element,{delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false},{left:'\\[',right:'\\]',display:true},{left:'\\(',right:'\\)',display:false}],throwOnError:false,trust:false,strict:'ignore',ignoredTags:['script','noscript','style','textarea','pre','code']});}catch{}}
function artifactButtons(id){
 const run=state.runs.get(id),r=run?.result||{},a=r.artifacts||{},group=node('div','run-artifact-actions');group.dataset.runId=id;
 const values={model:r.model||a.formulation||a.model,code:r.code||a.code,execution:r.execution||a.execution};
 for(const [tab,title]of[['model',t('查看模型','View model')],['code',t('查看代码','View code')],['execution',t('运行结果','Solve result')]]){const button=node('button','artifact-open-button',title);button.type='button';button.dataset.openArtifact=tab;button.dataset.runId=id;button.disabled=!values[tab];button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','inspector-panel');group.append(button);}
 return group;
}
function refreshArtifactButtons(id){
 const r=state.runs.get(id)?.result||{},a=r.artifacts||{},values={model:r.model||a.formulation||a.model,code:r.code||a.code,execution:r.execution||a.execution};
 for(const group of $$('.run-artifact-actions'))if(group.dataset.runId===id)for(const button of $$('[data-open-artifact]',group))button.disabled=!values[button.dataset.openArtifact];
}
function messageNode(message){const e=node('section',`message message-${message.role}`),h=node('div','message-header'),body=node('div','message-body');h.append(node('i','',message.role==='user'?'↑':'L'),node('span','',message.role==='user'?t('你','YOU'):'LEAN-LLM-OPT'));body.append(markdown(message.content));e.append(h,body);if(message.role==='assistant'&&message.run_id)e.append(artifactButtons(message.run_id));math(body);return e;}
function renderConversation(){const box=$('#conversation'),bottom=nearBottom(),top=box.scrollTop;state.processNodes.clear();state.stageNodes.clear();box.replaceChildren();const messages=state.session?.messages||[];if(!messages.length||!state.examplesCollapsed){const welcome=welcomeTemplate.cloneNode(true);translate(welcome);box.append(welcome);renderExampleCards();}for(const message of messages){box.append(messageNode(message));if(message.role==='user'&&message.run_id)box.append(processNode(message.run_id));}if(bottom)scrollBottom(true);else box.scrollTop=top;}
function processNode(id){const run=state.runs.get(id)||{id,status:'queued',events:[]},e=node('div','run-process'),caption=node('div','process-caption');e.dataset.runId=id;caption.append(node('span','',`${t('运行','RUN')} ${String(Math.max(0,(state.session?.runs||[]).indexOf(id))+1).padStart(2,'0')}`),node('span','process-state',label(run.status)));e.append(caption,artifactButtons(id));state.processNodes.set(id,e);state.stageNodes.set(id,new Map());if(run.events?.length){for(const event of run.events)stageEvent(id,event);}else if(run.result){const r=run.result;for(const [stage,payload]of[['classification',r.classification],['workflow',r.workflow],['data',r.data],['model',r.model?{formulation:r.model}:null],['code',r.code?{code:r.code}:null],['execution',r.execution]])if(payload)stageEvent(id,{stage,type:'completed',payload});}if(terminal.has(run.status))for(const card of state.stageNodes.get(id).values())if(card.classList.contains('running')){card.classList.remove('running');$('.stage-state',card).textContent=label(run.status);}return e;}
const stageCopy={classification:['理解当前请求','Reading your request'],workflow:['匹配参考示例','Matching reference examples'],data:['准备建模数据','Preparing model data'],model:['组织变量、目标与约束','Defining variables, objective and constraints'],code:['生成求解代码','Generating solver code'],execution:['提交求解','Submitting the solve'],output:['生成回复','Preparing the response']};
function summary(stage,p,type){if(p.message){if(type==='started'&&stageCopy[stage])return t(...stageCopy[stage]);if(p.name==='code-repair')return t('根据诊断修复代码','Repairing code from the diagnostic');return p.message;}if(stage==='classification')return p.label?p.label:p.intent==='explain'?t('说明当前模型。','Explaining the current model.'):p.intent==='clarify'?t('待补充信息。','Clarification needed.'):'';if(stage==='workflow'&&p.mode)return `${p.mode==='type-tailored'?t('类型定制工作流','Type-tailored workflow'):p.mode==='type-agnostic'?t('通用工作流','Type-agnostic workflow'):p.mode} · ${p.route||''} · ${p.examples?.length||0} ${t('个参考示例','references')}`;if(stage==='data'&&p.tables)return p.tables.map(f=>`${f.name} · ${f.row_count??'?'} ${t('行','rows')}`).join('\n');if(stage==='model'&&(p.formulation||p.content))return t('模型已生成。','Model generated.');if(stage==='code'&&(p.code||p.content))return t('求解程序已生成。','Solver code generated.');if(stage==='execution'&&p.status==='execution_unavailable')return t('求解器不可用，模型与代码已保留。','Solver unavailable; the model and code are retained.');if(stage==='execution'&&p.status)return `${label(p.status)}${p.objective!=null?` · ${t('目标值','Objective')} ${number(p.objective)}`:''}${p.error?`\n${p.error}`:''}`;if(stage==='output'&&p.answer)return p.answer;if(p.error)return p.error;return type==='completed'?t('已完成','Completed'):'';}
function stageEvent(id,event){if(!stages[event.stage])return;const process=state.processNodes.get(id);if(!process)return;const cards=state.stageNodes.get(id);let card=cards.get(event.stage);if(!card){card=node('div','stage-card running');const h=node('div','stage-heading');h.append(node('span','stage-icon',String(cards.size+1).padStart(2,'0')),node('strong','',t(...stages[event.stage])),node('span','stage-state',t('进行中','Working')));card.append(h,node('p','stage-detail'),node('div','stage-tools'),node('div','stage-token'));process.append(card);cards.set(event.stage,card);}const p=event.payload||{};if(event.type==='started'){card.className='stage-card running';$('.stage-state',card).textContent=t('进行中','Working');}if(['completed','error'].includes(event.type)){card.className=`stage-card ${event.type==='error'?'error':'completed'}`;$('.stage-state',card).textContent=event.type==='error'?t('错误','Error'):t('已完成','Done');$('.stage-icon',card).textContent=event.type==='error'?'!':'✓';}if(event.type==='token'){$('.stage-token',card).textContent+=p.text||'';return;}if(event.type==='tool')$('.stage-tools',card).textContent=`${p.name==='code-repair'?t('代码修复','Code repair'):p.name||t('工具','Tool')} · ${label(p.status||'')}${p.examples?` · ${p.examples.length} ${t('个参考示例','references')}`:''}`;const text=summary(event.stage,p,event.type);if(text)$('.stage-detail',card).textContent=text;}

function renderFiles(){const list=$('#file-list');list.replaceChildren();for(const f of state.previewMode?state.previewFiles:(state.session?.files||state.previewFiles)){const row=node('div','file-row'),open=node('button','file-open'),info=node('span','file-info');open.type='button';info.append(node('strong','',f.name),node('small','',`${f.row_count} ${t('行','rows')} · ${f.columns.length} ${t('列','columns')}`));open.append(node('span','csv-icon','CSV'),info);open.addEventListener('click',()=>preview(f));const remove=node('button','file-remove','×');remove.type='button';remove.hidden=Boolean(f.offline);remove.disabled=Boolean(state.activeRun);remove.setAttribute('aria-label',`${t('删除','Remove')} ${f.name}`);remove.addEventListener('click',()=>removeFile(f.id));row.append(open,remove);list.append(row);}$('#session-caption').textContent=state.previewMode?t('示例数据 · 本机运行时载入','Example data · loaded for local runs'):state.session?t('当前会话','Current session'):'';}
function preview(f){$('#preview-title').textContent=f.name;$('#preview-meta').textContent=`${f.row_count} ${t('行','rows')} · ${f.columns.length} ${t('列','columns')} · ${(f.size/1024).toFixed(1)} KB`;const table=node('table'),head=node('thead'),hr=node('tr'),body=node('tbody');for(const col of f.columns)hr.append(node('th','',col||t('(索引)','(index)')));head.append(hr);for(const values of f.preview||[]){const row=node('tr');for(const v of values)row.append(node('td','',v));body.append(row);}table.append(head,body);$('#preview-table').replaceChildren(table);$('#file-preview').showModal();}
async function upload(files){if(!state.session||state.activeRun||state.sending||!files.length)return;const form=new FormData();for(const file of files)form.append('files',file);notice();$('#upload-button').disabled=true;try{const p=await api(`/sessions/${state.session.id}/files`,{method:'POST',body:form});state.session.files=p.files;renderFiles();toast(t('CSV 已上传','CSV files uploaded'));}catch(e){notice(e.message);}finally{$('#file-input').value='';busy(state.activeRun);}}
async function removeFile(id){if(state.activeRun)return;try{const p=await api(`/sessions/${state.session.id}/files/${id}`,{method:'DELETE'});state.session.files=p.files;renderFiles();}catch(e){notice(e.message);}}
function closeSettings(restoreFocus=true){const wasOpen=document.body.classList.contains('settings-open');document.body.classList.remove('settings-open');$('#drawer-backdrop').hidden=true;$('#settings-open').setAttribute('aria-expanded','false');$('#settings-panel').removeAttribute('role');$('#settings-panel').removeAttribute('aria-modal');if(wasOpen&&restoreFocus)$('#settings-open').focus();}
function openSettings(){document.body.classList.add('settings-open');$('#drawer-backdrop').hidden=false;$('#settings-open').setAttribute('aria-expanded','true');$('#settings-panel').setAttribute('role','dialog');$('#settings-panel').setAttribute('aria-modal','true');$('#settings-close').focus();}
function drawerKeys(event){if(!document.body.classList.contains('settings-open')||$('#file-preview').open||$('#local-setup').open)return;if(event.key==='Escape'){event.preventDefault();closeSettings();return;}if(event.key!=='Tab')return;const items=$$('button:not(:disabled),input:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]',$('#settings-panel')).filter(element=>!element.hidden&&element.getClientRects().length);if(!items.length)return;const first=items[0],last=items.at(-1);if(!$('#settings-panel').contains(document.activeElement)){event.preventDefault();first.focus();return;}if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}

async function example(id){
 if(state.activeRun||state.sending||state.exampleLoading)return;const item=state.catalog.find(e=>e.id===id);if(!item){notice(t('示例目录尚未载入，请刷新后重试。','The example catalog is not ready. Refresh to retry.'));return;}
 state.pendingExample=id;state.previewMode=true;state.previewFiles=item.files.map((f,index)=>({...f,id:`preview-${index}`,offline:true,size:new TextEncoder().encode(f.content).length}));$('#query').value=local(item.query);resizeQuery();renderFiles();notice();
 if(!isLocalRuntime||!state.setupConfirmed||!state.session||!state.connected||$('#provider').value==='ollama'&&!state.capabilities?.ollama?.ready){openSetup(id);return;}
 state.exampleLoading=true;busy(null);
 try{if(state.session.messages?.length)await openSession();const p=await api(`/sessions/${state.session.id}/examples/${id}`,{method:'POST'});state.session.files=p.files;state.previewMode=false;state.previewFiles=[];state.pendingExample=null;$('#query').value=local(p.query);resizeQuery();renderFiles();closeSettings(false);await send();}catch(error){notice(error.message);}finally{state.exampleLoading=false;busy(state.activeRun);}
}
function renderVersions(){const select=$('#version-select');select.replaceChildren();const ids=state.session?.runs||[];if(!ids.length){select.append(node('option','',t('尚无运行记录','No runs yet')));return;}for(let i=ids.length-1;i>=0;i--){const id=ids[i],run=state.runs.get(id),option=node('option','',`${t('运行','Run')} ${String(i+1).padStart(2,'0')} · ${label(run?.status||'completed')}`);option.value=id;option.selected=id===state.selectedRun;select.append(option);}}
function result(){return state.runs.get(state.selectedRun)?.result||{};}
function artifact(){const r=result(),a=r.artifacts||{};return state.tab==='model'?r.model||a.formulation||a.model||'':state.tab==='code'?r.code||a.code||'':r.execution||a.execution||null;}
function number(n){return typeof n==='number'?new Intl.NumberFormat(state.lang==='en'?'en-US':'zh-CN',{maximumFractionDigits:6}).format(n):String(n);}
function safeArtifactUrl(value){try{const u=new URL(value,location.href);return u.origin===location.origin&&u.pathname.startsWith(`${API}/runs/${state.selectedRun}/artifacts/`)?u.href:null;}catch{return null;}}
function executionView(value){
 const root=node('div');let rawRecord=null;
 if(typeof value==='string'){try{value=JSON.parse(value);}catch{rawRecord=value;value={status:'record_only'};}}
 const status=value.status||'error',runStatus=state.runs.get(state.selectedRun)?.status||'saved';
 const overview=node('dl','result-status-grid');
 const addStatus=(title,content)=>{const row=node('div','result-status-row'),description=node('dd');description.append(typeof content==='string'?document.createTextNode(content):content);row.append(node('dt','',title),description);overview.append(row);};
 addStatus(t('流程状态','Run status'),label(runStatus));
 addStatus(t('求解状态','Solver status'),node('span',`result-status ${['optimal','completed'].includes(status)?'':'bad'}`,status==='record_only'?t('查看原始记录','See source record'):label(status)));
 addStatus(t('建模验证','Model review'),t('待人工确认','Pending review'));
 const statusHelp=node('details','status-help');statusHelp.append(node('summary','',t('状态说明','About these statuses')),node('p','validation-note',t('求解状态针对生成的数学模型；请依据业务目标和约束核对模型定义。','Solver status applies to the generated mathematical model. Review its definitions against the business objective and constraints.')));root.append(overview,statusHelp);
 if(rawRecord){root.append(node('pre','result-log',rawRecord));return root;}
 if(status==='solver_stopped'){const code=value.solver_status_code;root.append(node('p','field-hint',t('尚未证得最优解。','Optimality has not been proven.')+(code!=null?` ${t('状态码','Status code')}: ${code}`:'')));}

if(value.objective!=null)root.append(node('p','objective-label',t('求解目标值','SOLVER OBJECTIVE')),node('p','objective-value',number(value.objective)));if(status==='execution_unavailable')root.append(node('p','result-error',t('求解器不可用，尚未执行。','Solver unavailable. Not executed.')));else if(value.error)root.append(node('p','result-error',value.error));const variables=value.variables||value.solution||[];if(variables.length){const section=node('section','result-section');section.append(node('h3','',`${t('决策变量','DECISION VARIABLES')} / ${variables.length}`));const box=node('div','result-scroll'),table=node('table','result-table'),thead=node('thead'),head=node('tr'),body=node('tbody');head.append(node('th','',t('变量','Variable')),node('th','',t('取值','Value')));thead.append(head);for(const v of variables.slice(0,250)){const row=node('tr');row.append(node('td','',Array.isArray(v)?v[0]:v.name),node('td','',number(Array.isArray(v)?v[1]:v.value)));body.append(row);}table.append(thead,body);box.append(table);section.append(box);if(variables.length>250)section.append(node('p','field-hint',t('显示前 250 项；下载完整结果查看全部变量。','Showing 250 variables; download the full result for all values.')));root.append(section);}for(const[key,title]of[['stdout',t('标准输出','STANDARD OUTPUT')],['stderr',t('错误输出','ERROR OUTPUT')]])if(value[key]){const details=node('details','result-section');details.append(node('summary','',title),node('pre','result-log',value[key]));root.append(details);}return root;}
function renderArtifact(){
 const content=$('#artifact-content');content.replaceChildren();$$('[role="tab"][data-tab]').forEach(e=>{const active=e.dataset.tab===state.tab;e.classList.toggle('selected',active);e.setAttribute('aria-selected',String(active));e.tabIndex=active?0:-1;});content.setAttribute('aria-labelledby',`${state.tab}-tab`);$('#artifact-kind').textContent={model:'FORMULATION / PLAN',code:'PYTHON / GUROBI',execution:'EXECUTION RECORD'}[state.tab];const r=result();$('#artifact-indicator').textContent=String([r.model||r.artifacts?.formulation,r.code||r.artifacts?.code,r.execution||r.artifacts?.execution].filter(Boolean).length);const value=artifact();$('#copy-artifact').disabled=!value;$('#download-artifact').setAttribute('aria-disabled',String(!value));$('#download-artifact').tabIndex=value?0:-1;if(state.downloadUrl){URL.revokeObjectURL(state.downloadUrl);state.downloadUrl=null;}
 if(!value){const empty=node('div','artifact-empty');empty.append(node('span','empty-symbol',state.tab==='model'?'ƒ':state.tab==='code'?'{ }':'x*'),node('p','',state.tab==='model'?t('尚无数学模型或建模计划。','No formulation or model plan yet.'):state.tab==='code'?t('尚无生成代码。','No generated code yet.'):t('尚无求解结果。','No solve result yet.')));content.append(empty);$('#download-artifact').href='#';return;}
 if(state.tab==='model'){content.append(markdown(value));math(content);}else if(state.tab==='code'){const pre=node('pre','code-view');pre.append(node('code','',value));content.append(pre);}else content.append(executionView(value));
 const run=state.runs.get(state.selectedRun),filename={model:'formulation.md',code:'generated-model.py',execution:'execution.json'}[state.tab],saved=(run?.artifacts||[]).find(x=>x.name===filename);let url=saved?safeArtifactUrl(saved.url):null;if(!url){state.downloadUrl=URL.createObjectURL(new Blob([typeof value==='string'?value:JSON.stringify(value,null,2)],{type:state.tab==='execution'?'application/json':'text/plain;charset=utf-8'}));url=state.downloadUrl;}$('#download-artifact').href=url;$('#download-artifact').download=filename;
 if(state.tab==='execution'&&run?.artifacts?.length){const downloads=node('div','artifact-downloads');for(const item of run.artifacts){const href=safeArtifactUrl(item.url);if(href){const a=node('a','',item.name);a.href=href;a.download=item.name;downloads.append(a);}}content.append(downloads);}
}
function artifactEvent(run,event){run.result||={};const p=event.payload||{};if(event.type==='artifact'){if(p.kind==='formulation')run.result.model=p.content;else if(p.kind==='code')run.result.code=p.content;}if(event.type==='completed'){if(event.stage==='model'&&p.formulation)run.result.model=p.formulation;if(event.stage==='code'&&p.code)run.result.code=p.code;if(event.stage==='execution')run.result.execution=p;if(['classification','workflow','data'].includes(event.stage))run.result[event.stage]=p;}}
async function selectedVersion(id){state.selectedRun=id;if(id&&!state.runs.get(id)?.result)try{const run=await api(`/runs/${id}`);state.runs.set(id,{...state.runs.get(id),...run});}catch(e){notice(e.message);}renderVersions();renderArtifact();}
async function finish(id,event){const run=state.runs.get(id);if(!run)return;run.status=event.type;run.result=event.payload?.result||run.result;run.artifacts=event.payload?.artifacts||run.artifacts||[];if(event.payload?.error)run.error=event.payload.error;state.source?.close();state.source=null;try{Object.assign(run,await api(`/runs/${id}`));}catch{}if(state.session&&!state.session.messages.some(m=>m.role==='assistant'&&m.run_id===id))state.session.messages.push({role:'assistant',content:run.result?.answer||run.error||label(run.status),run_id:id});if(state.activeRun===id)busy(null);renderConversation();renderVersions();renderArtifact();scrollBottom(true);if(run.error)notice(run.error);}
function watch(id,after=0){
 state.source?.close();const source=new EventSource(`${API}/runs/${id}/events?after=${after}`,{withCredentials:true});state.source=source;
 source.onmessage=event=>{let record;try{record=JSON.parse(event.data);}catch{return;}if(record.run_id!==id||record.seq<=(state.lastSeq.get(id)||0))return;state.lastSeq.set(id,record.seq);publishRunEvent(record);const run=state.runs.get(id);if(!run)return;run.events||=[];run.events.push(record);const bottom=nearBottom();if(record.stage==='run'){if(record.type==='queued')run.status='queued';if(record.type==='started')run.status='running';const p=state.processNodes.get(id);if(p)$('.process-state',p).textContent=label(record.type==='started'?'running':record.type);if(terminal.has(record.type)){finish(id,record);return;}}else{stageEvent(id,record);artifactEvent(run,record);if(record.type==='artifact'||record.type==='completed')refreshArtifactButtons(id);if(state.selectedRun===id&&(record.type==='artifact'||(record.type==='completed'&&['model','code','execution'].includes(record.stage))))renderArtifact();}if(bottom)scrollBottom(true);renderVersions();};
 source.onerror=async()=>{if(state.source!==source)return;try{const run=await api(`/runs/${id}`);if(terminal.has(run.status)){finish(id,{type:run.status,payload:{result:run.result,error:run.error,artifacts:run.artifacts}});return;}}catch{}const p=state.processNodes.get(id);if(p)$('.process-state',p).textContent=t('重新连接中','Reconnecting');};
}
async function send(){if(!isLocalRuntime||!state.setupConfirmed||!state.session||!state.connected||$('#provider').value==='ollama'&&!state.capabilities?.ollama?.ready){state.pendingSend=true;openSetup();return;}const query=$('#query').value.trim();if(!query||!state.session||state.activeRun||state.sending)return;if($('#provider').value==='openai'&&!$('#api-key').value.trim()){notice(t('请填写 OpenAI API key。','Enter your OpenAI API key.'));$('#api-key').focus();return;}notice();state.sending=true;$('#send-button').disabled=true;try{const p=await api(`/sessions/${state.session.id}/messages`,{method:'POST',body:JSON.stringify({content:query,provider:$('#provider').value,model:$('#model').value,api_key:$('#api-key').value.trim(),language:state.lang})}),id=p.run_id;state.runs.set(id,{...p.run,id,status:p.status,events:[],result:null});state.session.runs.push(id);state.session.messages.push({role:'user',content:query,run_id:id});state.selectedRun=id;$('#query').value='';resizeQuery();busy(id);examplesView(false,false);renderVersions();renderArtifact();scrollBottom(true);watch(id);}catch(e){notice(e.message);busy(null);}finally{state.sending=false;busy(state.activeRun);}}
async function cancel(){if(!state.activeRun)return;$('#cancel-button').disabled=true;try{await api(`/runs/${state.activeRun}/cancel`,{method:'POST'});toast(t('正在停止运行…','Stopping the run…'));}catch(e){notice(e.message);$('#cancel-button').disabled=false;}}
async function openSession(id){state.source?.close();state.source=null;const session=id?await api(`/sessions/${encodeURIComponent(id)}`):await api('/sessions',{method:'POST'});state.session={...session,id:session.id||session.session_id};state.runs.clear();state.lastSeq.clear();state.selectedRun=null;store('lean-demo-session',state.session.id);const url=new URL(location.href);url.searchParams.set('session',state.session.id);history.replaceState(null,'',url);publishSession(state.session.id);for(const runId of session.runs||[])state.runs.set(runId,{id:runId,status:'saved',result:null,events:[]});await Promise.all((session.runs||[]).slice(-8).map(async runId=>{try{state.runs.set(runId,{...await api(`/runs/${runId}`),events:[]});}catch{}}));state.selectedRun=(session.runs||[]).at(-1)||null;const active=[...state.runs.values()].find(r=>['queued','running'].includes(r.status));busy(active?.id||active?.run_id||null);renderFiles();renderVersions();renderConversation();renderArtifact();researchHome();if(active)watch(active.id||active.run_id);}
function resizeQuery(){const e=$('#query');e.style.height='auto';e.style.height=Math.min(e.scrollHeight,170)+'px';}
function examplesView(show,restoreFocus=true){
 state.examplesCollapsed=!show;document.body.classList.toggle('examples-collapsed',!show);$('#examples-toggle').setAttribute('aria-expanded',String(show));renderConversation();
 if(restoreFocus)$(show?'#examples-hide':'#examples-toggle')?.focus();
}
function artifactsView(show,trigger=document.activeElement){
 const wasOpen=document.body.classList.contains('artifacts-open'),panel=$('#inspector-panel');
 if(show&&!wasOpen){state.artifactTrigger=trigger;closeSettings(false);}
 document.body.classList.toggle('artifacts-open',show);panel.hidden=!show;panel.inert=!show;$('#artifact-backdrop').hidden=!show;
 for(const element of [$('.studio-header'),$('.mobile-view-tabs'),$('#settings-panel'),$('#conversation-panel')])element.inert=show;
 $('#conversation-view').classList.toggle('selected',!show);$('#artifacts-view').classList.toggle('selected',show);$('#conversation-view').setAttribute('aria-pressed',String(!show));$('#artifacts-view').setAttribute('aria-pressed',String(show));$('#results-open').setAttribute('aria-expanded',String(show));
 if(show&&!wasOpen)$('#inspector-close').focus();
 if(!show&&wasOpen){const previous=state.artifactTrigger;state.artifactTrigger=null;(previous?.isConnected&&previous.getClientRects().length?previous:$('#results-open')).focus();}
}
async function openArtifact(id,tab,trigger=document.activeElement){
 if(!state.runs.has(id)||!['model','code','execution'].includes(tab))return;
 state.tab=tab;await selectedVersion(id);artifactsView(true,trigger);
}
function artifactKeys(event){
 if(!document.body.classList.contains('artifacts-open')||$('#file-preview').open||$('#local-setup').open)return;
 if(event.key==='Escape'){event.preventDefault();artifactsView(false);return;}
 if(event.key!=='Tab')return;
 const panel=$('#inspector-panel'),items=$$('button:not(:disabled),input:not(:disabled),select:not(:disabled),a[href]:not([aria-disabled="true"]),[tabindex="0"]',panel).filter(element=>!element.hidden&&element.getClientRects().length);
 if(!items.length)return;const first=items[0],last=items.at(-1),active=document.activeElement;
 if(!panel.contains(active)){event.preventDefault();first.focus();}else if(event.shiftKey&&active===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&active===last){event.preventDefault();first.focus();}
}
$('#composer').addEventListener('submit',e=>{e.preventDefault();send();});$('#query').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send();}});$('#query').addEventListener('input',resizeQuery);$('#cancel-button').addEventListener('click',cancel);
$('#provider').addEventListener('change',()=>{const openai=$('#provider').value==='openai';state.setupConfirmed=false;$('#key-field').hidden=!openai||!isLocalRuntime;$('#model').value=openai?'gpt-4.1':'gpt-oss:20b';$('#model').readOnly=!openai;if(!openai)$('#api-key').value='';renderHealth();openSetup();});
$('#upload-button').addEventListener('click',()=>$('#file-input').click());$('#drop-zone').addEventListener('click',()=>$('#file-input').click());$('#file-input').addEventListener('change',()=>upload([...$('#file-input').files]));
for(const name of ['dragenter','dragover'])$('#drop-zone').addEventListener(name,e=>{e.preventDefault();$('#drop-zone').classList.add('dragging');});for(const name of ['dragleave','drop'])$('#drop-zone').addEventListener(name,e=>{e.preventDefault();$('#drop-zone').classList.remove('dragging');if(name==='drop')upload([...e.dataTransfer.files]);});
document.addEventListener('click',e=>{const button=e.target.closest('[data-example]');if(button)example(button.dataset.example);const action=e.target.closest('[data-open-artifact]');if(action&&!action.disabled)openArtifact(action.dataset.runId,action.dataset.openArtifact,action);if(e.target.closest('#examples-hide'))examplesView(false);});
$('#new-session').addEventListener('click',async()=>{if(state.activeRun||state.sending)return;if(!isLocalRuntime||!state.setupConfirmed){openSetup();return;}try{notice();state.previewMode=false;await openSession();$('#query').value='';resizeQuery();examplesView(true,false);closeSettings();toast(t('新对话已创建','New conversation created'));}catch(e){notice(e.message);}});
$('#settings-open').addEventListener('click',openSettings);$('#settings-close').addEventListener('click',()=>closeSettings());$('#drawer-backdrop').addEventListener('click',()=>closeSettings());document.addEventListener('keydown',drawerKeys);$('#conversation-view').addEventListener('click',()=>artifactsView(false));$('#artifacts-view').addEventListener('click',()=>artifactsView(true));
$('#examples-toggle').addEventListener('click',()=>examplesView(state.examplesCollapsed));$('#results-open').addEventListener('click',event=>artifactsView(true,event.currentTarget));$('#inspector-close').addEventListener('click',()=>artifactsView(false));$('#artifact-backdrop').addEventListener('click',()=>artifactsView(false));document.addEventListener('keydown',artifactKeys);
$('.mobile-view-tabs').addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const show=event.key==='End'?true:event.key==='Home'?false:!document.body.classList.contains('artifacts-open');artifactsView(show);if(!show)$('#conversation-view').focus();});
matchMedia('(max-width:950px)').addEventListener('change',event=>{if(!event.matches)closeSettings(false);});
$('#preview-close').addEventListener('click',()=>$('#file-preview').close());$('#file-preview').addEventListener('click',e=>{if(e.target===$('#file-preview')){const b=e.target.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)e.target.close();}});
$$('[role="tab"][data-tab]').forEach(e=>e.addEventListener('click',()=>{state.tab=e.dataset.tab;renderArtifact();}));$('.artifact-tabs').addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const keys=['model','code','execution'],i=keys.indexOf(state.tab);state.tab=e.key==='Home'?keys[0]:e.key==='End'?keys.at(-1):keys[(i+(e.key==='ArrowRight'?1:2))%3];renderArtifact();$(`#${state.tab}-tab`).focus();});$('#version-select').addEventListener('change',e=>selectedVersion(e.target.value));
$('#copy-artifact').addEventListener('click',async()=>{const value=artifact();if(!value)return;try{await navigator.clipboard.writeText(typeof value==='string'?value:JSON.stringify(value,null,2));toast(t('已复制','Copied'));}catch{notice(t('复制不可用，请使用下载。','Clipboard unavailable; use the download link.'));}});
$('#language-toggle').addEventListener('click',()=>preferences(state.lang==='en'?'zh':'en',state.theme,true));$('#theme-toggle').addEventListener('click',()=>preferences(state.lang,state.theme==='dark'?'light':'dark',true));
window.addEventListener('pagehide',()=>{state.source?.close();runChannel?.close();runChannel=null;$('#api-key').value='';$('#setup-api-key').value='';state.setupConfirmed=false;if(state.downloadUrl)URL.revokeObjectURL(state.downloadUrl);});
window.addEventListener('pageshow',event=>{if(!event.persisted)return;runChannel=createRunChannel();if(state.session)publishSession(state.session.id);if(state.activeRun)watch(state.activeRun,state.lastSeq.get(state.activeRun)||0);renderArtifact();});
$('#local-setup-open').addEventListener('click',()=>openSetup());$('#model-setup-open').addEventListener('click',()=>openSetup());
$('#setup-close').addEventListener('click',()=>$('#local-setup').close());$('#setup-confirm').addEventListener('click',confirmSetup);$('#setup-detect').addEventListener('click',async()=>{state.setupError='';await health();updateSetup();});$('#runtime-check').addEventListener('click',checkRuntime);
$('#local-setup').addEventListener('close',()=>{$('#setup-api-key').value='';});
$$('[data-copy-command]').forEach(button=>button.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(document.getElementById(button.dataset.copyCommand).textContent);toast(t('命令已复制','Command copied'));}catch{toast(t('请选中命令复制。','Select the command text to copy it.'));}}));
$('#setup-provider-ollama').addEventListener('click',()=>{$('#provider').value='ollama';$('#provider').dispatchEvent(new Event('change'));});$('#setup-provider-openai').addEventListener('click',()=>{$('#provider').value='openai';$('#provider').dispatchEvent(new Event('change'));});
if(params.get('provider')==='openai'){$('#provider').value='openai';$('#model').value='gpt-4.1';$('#model').readOnly=false;}else if(isLocalRuntime||params.get('provider')==='ollama'){$('#provider').value='ollama';}else{$('#provider').value='';$('#model').value='';}
preferences(state.lang,state.theme);
try{await loadCatalog();}catch(error){notice(error.message);}
await health();
if(EXAMPLE_IDS.has(params.get('example'))){state.pendingExample=params.get('example');const cleanURL=new URL(location.href);cleanURL.searchParams.delete('example');cleanURL.searchParams.delete('autorun');history.replaceState(null,'',cleanURL);await example(state.pendingExample);}
else if(isLocalRuntime)openSetup();
// Local polling reads model/service metadata only; it never warms a solver or model.
setInterval(()=>{if(isLocalRuntime&&!document.hidden&&!state.activeRun)health().then(()=>{if($('#local-setup').open)updateSetup();});},30000);
