"""Local interactive LEAN-LLM-OPT demonstration service."""

__version__ = "0.1.0"
