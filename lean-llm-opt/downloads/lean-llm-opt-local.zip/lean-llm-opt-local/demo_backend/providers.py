"""Per-run model clients. Credentials are explicit; no environment files are loaded."""
from __future__ import annotations

import json
import re
import time
from typing import Callable

import httpx


class ProviderError(RuntimeError):
    pass


def visible_text(text: str) -> str:
    """Exclude reasoning fields/tags from user-visible provider content."""
    return re.sub(r"<think(?:ing)?>[\s\S]*?(?:</think(?:ing)?>|$)", "", text, flags=re.I).strip()


class ModelProvider:
    def __init__(self, *, provider: str, model: str = "", api_key: str = "",
                 ollama_url: str = "http://127.0.0.1:11434", timeout: float = 240,
                 deadline_monotonic: float | None = None):
        if provider not in {"ollama", "openai"}:
            raise ProviderError("Unsupported model provider")
        if provider == "openai" and not api_key:
            raise ProviderError("An explicit OpenAI API key is required")
        self.provider = provider
        self.model = model or ("gpt-oss:20b" if provider == "ollama" else "gpt-4.1")
        self.embedding_model = "nomic-embed-text" if provider == "ollama" else "text-embedding-3-small"
        self.timeout, self.deadline_monotonic = timeout, deadline_monotonic
        self.base_url = ollama_url.rstrip("/") if provider == "ollama" else "https://api.openai.com"
        headers = {"Authorization": f"Bearer {api_key}"} if provider == "openai" else {}
        self.client = httpx.Client(headers=headers, timeout=httpx.Timeout(timeout, connect=10), trust_env=False)

    def close(self):
        self.client.close()

    def _request_timeout(self):
        remaining = self.timeout if self.deadline_monotonic is None else min(
            self.timeout, self.deadline_monotonic - time.monotonic())
        if remaining <= 0:
            raise ProviderError("Run deadline exceeded")
        return httpx.Timeout(remaining, connect=min(10, remaining))

    @staticmethod
    def _check(response):
        if response.is_error:
            # Error response bodies may contain submitted data; never echo them.
            raise ProviderError(f"Model service returned HTTP {response.status_code}")

    def embed(self, texts: list[str], *, cancelled: Callable[[], bool] = lambda: False) -> list[list[float]]:
        if cancelled():
            raise ProviderError("Run cancelled")
        endpoint = "/api/embed" if self.provider == "ollama" else "/v1/embeddings"
        body = {"model": self.embedding_model, "input": texts}
        try:
            response = self.client.post(self.base_url + endpoint, json=body, timeout=self._request_timeout())
            self._check(response)
            data = response.json()
            vectors = data["embeddings"] if self.provider == "ollama" else [
                item["embedding"] for item in sorted(data["data"], key=lambda item: item["index"])
            ]
        except ProviderError:
            raise
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise ProviderError("Embedding service failed; check the selected provider and embedding model") from exc
        if len(vectors) != len(texts) or not all(isinstance(v, list) and v for v in vectors):
            raise ProviderError("Embedding service returned an invalid vector batch")
        return vectors

    def complete(self, messages: list[dict], *, json_mode: bool = False,
                 on_token=None, cancelled: Callable[[], bool] = lambda: False) -> str:
        endpoint = "/api/chat" if self.provider == "ollama" else "/v1/chat/completions"
        body = {"model": self.model, "messages": messages, "stream": True}
        if self.provider == "ollama":
            body["options"] = {"temperature": 0, "num_ctx": 32768, "num_predict": 8192}
            if self.model.startswith("gpt-oss"):
                body["think"] = "low"
            if json_mode:
                body["format"] = "json"
        else:
            body["temperature"] = 0
            if json_mode:
                body["response_format"] = {"type": "json_object"}
        content = []
        truncated = False
        try:
            with self.client.stream("POST", self.base_url + endpoint, json=body, timeout=self._request_timeout()) as response:
                self._check(response)
                for line in response.iter_lines():
                    if cancelled():
                        raise ProviderError("Run cancelled")
                    if not line or line.startswith(":"):
                        continue
                    if self.provider == "openai":
                        if not line.startswith("data:"):
                            continue
                        line = line[5:].strip()
                        if line == "[DONE]":
                            break
                    item = json.loads(line)
                    if item.get("error"):
                        raise ProviderError("Model service reported a generation error")
                    if self.provider == "ollama":
                        # Deliberately ignore message.thinking / reasoning content.
                        text = item.get("message", {}).get("content", "")
                        truncated |= item.get("done_reason") == "length"
                    else:
                        choice = (item.get("choices") or [{}])[0]
                        text = choice.get("delta", {}).get("content", "")
                        truncated |= choice.get("finish_reason") == "length"
                    if text:
                        content.append(text)
        except ProviderError:
            raise
        except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
            raise ProviderError("Model generation failed; check the selected model service") from exc
        if truncated:
            raise ProviderError("Model output was truncated; no partial program was executed")
        result = visible_text("".join(content))
        if not result:
            raise ProviderError("Model returned no visible answer")
        # Buffer before emission so fragmented <think> tags can never leak reasoning.
        if on_token:
            for chunk in re.findall(r".{1,80}(?:\s|$)|.{1,80}", result, flags=re.S):
                if cancelled():
                    raise ProviderError("Run cancelled")
                on_token(chunk)
        return result


def create_provider(context: dict) -> ModelProvider:
    return ModelProvider(provider=context.get("provider", "ollama"), model=context.get("model", ""),
                         api_key=context.get("api_key", ""),
                         ollama_url=context.get("ollama_url", "http://127.0.0.1:11434"),
                         deadline_monotonic=context.get("deadline_monotonic"))
