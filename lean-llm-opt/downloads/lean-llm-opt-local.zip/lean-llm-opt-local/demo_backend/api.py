"""Same-origin local/cloud API, in-memory sessions, and one bounded run queue."""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import io
import json
import os
from pathlib import Path
import queue
import re
import shutil
import tempfile
import threading
import time
import uuid
from typing import Any
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .runtime import DockerExecutor
from .local_setup import ollama_status
from .config import DeploymentConfig

PREFIX = "/api/demo"
COOKIE = "lean_demo_owner"
MAX_FILES = 10
MAX_BYTES = 50 * 1024 * 1024
MAX_SECONDS = 30 * 60
TERMINAL = {"completed", "failed", "cancelled", "timeout"}


def loopback_host(host: str) -> bool:
    match = re.fullmatch(r"(?:localhost|127\.0\.0\.1|\[::1\])(?::([0-9]{1,5}))?", host, re.I)
    return bool(match and (match.group(1) is None or 0 < int(match.group(1)) <= 65535))


class UploadLimitError(Exception):
    pass


class ResourceLimitError(Exception):
    pass


class BodyLimitMiddleware:
    def __init__(self, app, limit):
        self.app = app
        self.limit = limit

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope.get("path", "").startswith(PREFIX):
            return await self.app(scope, receive, send)
        total = 0
        async def limited_receive():
            nonlocal total
            message = await receive()
            if message["type"] == "http.request":
                total += len(message.get("body", b""))
                if total > self.limit:
                    raise UploadLimitError()
            return message
        return await self.app(scope, limited_receive, send)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def redact_credential(value, secret):
    """Remove only the configured credential, preserving ordinary task text."""
    if not secret:
        return value
    if isinstance(value, str):
        return value.replace(secret, "[redacted]")
    if isinstance(value, dict):
        return {key: redact_credential(item, secret) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_credential(item, secret) for item in value]
    return value


def clean_payload(value, secret=""):
    if isinstance(value, dict):
        return {str(k): clean_payload(v, secret) for k, v in value.items() if str(k).lower() not in {"api_key", "authorization", "password", "secret", "headers"}}
    if isinstance(value, (list, tuple)):
        return [clean_payload(v, secret) for v in value]
    if isinstance(value, Path):
        return value.name
    if isinstance(value, str):
        value = value.replace(secret, "[redacted]") if secret else value
        value = re.sub(r"(?i)bearer\s+[A-Za-z0-9._-]+|\bsk-[A-Za-z0-9_-]+", "[redacted]", value)
        return value
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)


@dataclass
class Session:
    id: str
    owner: str
    directory: Path
    created_at: str = field(default_factory=now)
    files: list = field(default_factory=list)
    messages: list = field(default_factory=list)
    runs: list = field(default_factory=list)
    touched: float = field(default_factory=time.monotonic)


@dataclass
class Run:
    id: str
    session_id: str
    owner: str
    directory: Path
    context: dict
    status: str = "queued"
    created_at: str = field(default_factory=now)
    started: float = field(default_factory=time.monotonic)
    events: list = field(default_factory=list)
    result: Any = None
    error: str | None = None
    artifacts: dict = field(default_factory=dict)
    cancel: threading.Event = field(default_factory=threading.Event)
    condition: threading.Condition = field(default_factory=threading.Condition)
    limits: Any = None
    sequence: int = 0
    event_sizes: list = field(default_factory=list)
    retained_event_bytes: int = 0

    def cancelled(self):
        return self.cancel.is_set() or time.monotonic() - self.started > MAX_SECONDS

    def emit(self, stage, kind, payload=None):
        with self.condition:
            event = {"seq": self.sequence + 1, "run_id": self.id, "stage": stage, "type": kind, "payload": clean_payload(payload or {}, self.context.get("api_key", "")), "timestamp": now()}
            size = len(json.dumps(event, ensure_ascii=False).encode("utf-8"))
            if self.limits and size > self.limits.event_bytes:
                if stage == "run" and kind in TERMINAL:
                    # The full result remains available through GET /runs/id.
                    event["payload"].pop("result", None)
                    size = len(json.dumps(event, ensure_ascii=False).encode("utf-8"))
                else:
                    raise ResourceLimitError("Run event exceeds the retention limit")
            self.sequence += 1
            self.events.append(event)
            self.event_sizes.append(size)
            self.retained_event_bytes += size
            if self.limits:
                while len(self.events) > self.limits.event_count or self.retained_event_bytes > self.limits.event_bytes:
                    self.events.pop(0)
                    self.retained_event_bytes -= self.event_sizes.pop(0)
            self.condition.notify_all()

    def terminate(self, status, payload):
        with self.condition:
            self.status = status
            self.emit("run", status, payload)


class MessageBody(BaseModel):
    content: str = Field(min_length=1, max_length=100_000)
    provider: str = Field(default="ollama", max_length=30)
    model: str = Field(default="", max_length=100)
    api_key: str = Field(default="", max_length=1000)
    language: str = "zh"


class Store:
    def __init__(self, root: Path, executor=None, pipeline=None, config=None):
        self.root = root
        root.mkdir(parents=True, exist_ok=True); root.chmod(0o700)
        self.sessions = {}; self.runs = {}
        self.lock = threading.RLock()
        self.queue = queue.Queue()
        self.executor = executor or DockerExecutor()
        self.pipeline = pipeline
        self.stopping = threading.Event()
        self.thread = None
        self.config = config or DeploymentConfig()
        self.limits = self.config.limits if self.config.cloud else None
        self.maintenance_thread = None
        self.runtime = {"ready": False, "checked": False, "status": "starting"}
        self.runtime_checked = 0.0
        self.sse_counts = {}
        self.rates = {}

    def probe_runtime(self):
        try:
            raw = self.executor.health(refresh=False)
            # Publish readiness only, never host paths/license diagnostics.
            self.runtime = {"ready": bool(raw.get("ready")), "checked": True,
                            "status": "ready" if raw.get("ready") else "unavailable"}
        except Exception:
            self.runtime = {"ready": False, "checked": True, "status": "unavailable"}
        self.runtime_checked = time.monotonic()

    @staticmethod
    def directory_bytes(directory):
        total = 0
        for base, dirs, files in os.walk(directory, followlinks=False):
            dirs[:] = [name for name in dirs if not (Path(base) / name).is_symlink()]
            for name in files:
                p = Path(base) / name
                try:
                    if not p.is_symlink():
                        total += p.stat().st_size
                except FileNotFoundError:
                    pass
        return total

    def check_storage(self, session, added=0):
        if self.sessions.get(session.id) is not session:
            raise HTTPException(404, "Session not found")
        if self.limits and (self.directory_bytes(session.directory) + added > self.limits.session_bytes
                            or self.directory_bytes(self.root) + added > self.limits.total_bytes):
            raise HTTPException(413, "Workspace storage limit reached")

    def cleanup(self):
        if not self.limits:
            return
        current = time.monotonic()
        with self.lock:
            for session in list(self.sessions.values()):
                active = [self.runs[rid] for rid in session.runs if self.runs[rid].status not in TERMINAL]
                expired = current - session.touched > self.limits.session_ttl
                for run in active:
                    if expired or current - run.started > MAX_SECONDS:
                        if run.status == "queued":
                            run.context.pop("api_key", None)
                            run.terminate("timeout", {})
                        else:
                            run.cancel.set()
                if expired and not active:
                    for rid in session.runs:
                        self.runs.pop(rid, None)
                    self.sessions.pop(session.id, None)
                    shutil.rmtree(session.directory, ignore_errors=True)
            self.rates = {key: item for key, item in self.rates.items() if current - item[0] < 60}

    def maintain(self):
        while not self.stopping.wait(5):
            self.cleanup()
            if time.monotonic() - self.runtime_checked >= 60 and not any(r.status == "running" for r in list(self.runs.values())):
                self.probe_runtime()

    def allow_request(self, identity, write):
        if not self.limits:
            return True
        current = time.monotonic()
        with self.lock:
            for kind, maximum in (("all", self.limits.requests_per_minute), ("write", self.limits.writes_per_minute)):
                if kind == "write" and not write:
                    continue
                key = (identity, kind)
                start, count = self.rates.get(key, (current, 0))
                if current - start >= 60:
                    start, count = current, 0
                if count >= maximum or key not in self.rates and len(self.rates) >= 4096:
                    return False
                self.rates[key] = (start, count + 1)
        return True

    def start(self):
        if self.limits:
            self.probe_runtime()
            self.maintenance_thread = threading.Thread(target=self.maintain, name="lean-demo-maintenance", daemon=True)
            self.maintenance_thread.start()
        self.thread = threading.Thread(target=self.work, name="lean-demo-queue", daemon=True)
        self.thread.start()

    def stop(self):
        self.stopping.set()
        for run in list(self.runs.values()):
            if run.status not in TERMINAL:
                run.cancel.set()
                if run.status == "queued":
                    run.context.pop("api_key", None)
                    run.terminate("cancelled", {})
        self.queue.put(None)
        if self.thread:
            self.thread.join(2)
        if self.maintenance_thread:
            self.maintenance_thread.join(2)
        close = getattr(self.executor, "close", None)
        if close:
            close()

    def register_artifacts(self, run):
        output = run.directory / "outputs"
        result = run.result if isinstance(run.result, dict) else {}
        for key, filename in [("query", "query.txt"), ("model", "formulation.md"), ("code", "generated-model.py"), ("answer", "answer.md")]:
            text = result.get(key)
            if isinstance(text, str) and text:
                (output / filename).write_text(clean_payload(text, run.context.get("api_key", "")), encoding="utf-8")
        for key in ["workflow", "data", "execution"]:
            if result.get(key) is not None:
                (output / (key + ".json")).write_text(json.dumps(clean_payload(result[key], run.context.get("api_key", "")), ensure_ascii=False, indent=2), encoding="utf-8")
        # Only plain files in the run's output root are downloadable; no symlinks.
        for p in output.iterdir():
            if p.is_file() and not p.is_symlink() and p.resolve().parent == output.resolve() and p.stat().st_size <= MAX_BYTES:
                run.artifacts[p.name] = p
        if self.limits:
            self.check_storage(self.sessions[run.session_id])

    def work(self):
        while not self.stopping.is_set():
            rid = self.queue.get()
            if rid is None:
                break
            with self.lock:
                run = self.runs.get(rid)
                if not run or run.status in TERMINAL:
                    continue
                if run.cancelled():
                    status = "cancelled" if run.cancel.is_set() else "timeout"
                    run.context.pop("api_key", None)
                    run.terminate(status, {})
                    continue
                run.status = "running"
            run.emit("run", "started", {})
            try:
                if self.pipeline is None:
                    from .pipeline import run_pipeline
                    pipeline = run_pipeline
                else:
                    pipeline = self.pipeline
                def execute(code, input_dir, **options):
                    secret = run.context.get("api_key", "")
                    if secret and secret in code:
                        raise ValueError("Generated program contains the configured credential")
                    if isinstance(self.executor, DockerExecutor):
                        options["worker_key"] = run.owner
                    return self.executor.execute(code, input_dir, **options)
                run.result = clean_payload(pipeline(run.context, run.emit, execute, run.cancelled), run.context.get("api_key", ""))
                if self.limits and len(json.dumps(run.result, ensure_ascii=False).encode("utf-8")) > self.limits.result_bytes:
                    run.result = None
                    raise ResourceLimitError("Run result exceeds the retention limit")
                if run.cancelled():
                    status = "cancelled" if run.cancel.is_set() else "timeout"
                else:
                    status = "completed"
                self.register_artifacts(run)
                session = self.sessions[run.session_id]
                answer = run.result.get("answer", "") if isinstance(run.result, dict) else str(run.result)
                session.messages.append({"id": uuid.uuid4().hex, "role": "assistant", "content": answer, "run_id": run.id, "created_at": now()})
                session.touched = time.monotonic()
                run.terminate(status, {"result": run.result, "artifacts": artifact_list(run)})
            except BaseException as exc:
                # Never log exception text/tracebacks: provider exceptions can contain keys.
                kind = type(exc).__name__
                status = "cancelled" if run.cancel.is_set() else "timeout" if run.cancelled() else "cancelled" if kind == "PipelineCancelled" else "failed"
                run.error = "Run cancelled" if status == "cancelled" else "Run exceeded 30 minutes" if status == "timeout" else f"Pipeline failed ({kind})"
                partial = {"answer": "", "execution": None}
                for event in run.events:
                    payload = event.get("payload", {})
                    if event.get("type") == "artifact" and isinstance(payload, dict):
                        key = {"formulation": "model"}.get(payload.get("kind"), payload.get("kind"))
                        if key in {"model", "code", "data", "workflow"}:
                            partial[key] = payload.get("content")
                run.result = clean_payload(partial, run.context.get("api_key", ""))
                try:
                    self.register_artifacts(run)
                except (HTTPException, ResourceLimitError):
                    run.artifacts.clear()
                    shutil.rmtree(run.directory / "outputs", ignore_errors=True)
                run.terminate(status, {"error": run.error, "result": run.result, "artifacts": artifact_list(run)})
            finally:
                run.context.pop("api_key", None)


def artifact_list(run):
    return [{"name": name, "url": f"{PREFIX}/runs/{run.id}/artifacts/{name}"} for name in sorted(run.artifacts)]


def run_view(run):
    with run.condition:
        return {"id": run.id, "run_id": run.id, "session_id": run.session_id, "status": run.status, "created_at": run.created_at, "last_seq": run.sequence, "first_seq": run.events[0]["seq"] if run.events else 0, "result": run.result, "error": run.error, "artifacts": artifact_list(run)}


def session_view(session):
    try:
        from .examples import list_examples
        examples = list_examples()
    except ImportError:
        examples = []
    return {"id": session.id, "session_id": session.id, "created_at": session.created_at, "files": [{k: v for k, v in f.items() if k != "path"} for f in session.files], "messages": session.messages, "runs": session.runs, "examples": examples}


def prior_result(session, store):
    for rid in reversed(session.runs):
        result = store.runs[rid].result
        if not isinstance(result, dict):
            continue
        nested = result.get("artifacts") if isinstance(result.get("artifacts"), dict) else {}
        if any(result.get(key) or nested.get(key) for key in ("query", "formulation", "model", "code", "answer")):
            return result
    return {}


def csv_metadata(content: bytes, filename: str):
    if not content or b"\x00" in content:
        raise HTTPException(400, "CSV must contain UTF-8 text")
    try:
        text = content.decode("utf-8-sig")
        reader = csv.reader(io.StringIO(text))
        columns = next(reader)
        if not columns or len(columns) > 1000:
            raise ValueError()
        preview = []; count = 0
        for row in reader:
            count += 1
            if len(preview) < 20:
                preview.append(row)
        return {"name": filename, "size": len(content), "columns": columns, "preview": preview, "row_count": count}
    except (UnicodeError, csv.Error, StopIteration, ValueError):
        raise HTTPException(400, "Invalid UTF-8 CSV")


def valid_filename(name):
    if not name or len(name) > 120 or Path(name).name != name or "/" in name or "\\" in name or not name.lower().endswith(".csv") or any(ord(ch) < 32 for ch in name):
        raise HTTPException(400, "Use a plain CSV filename")
    return name


def create_app(*, data_root=None, executor=None, pipeline=None, website_root=None, config=None):
    config = config or DeploymentConfig.from_env()
    owned_root = data_root is None
    root = Path(data_root or tempfile.mkdtemp(prefix="lean-demo-private-"))
    store = Store(root, executor=executor, pipeline=pipeline, config=config)
    @asynccontextmanager
    async def lifespan(app):
        store.start()
        yield
        store.stop()
        if owned_root and (not store.thread or not store.thread.is_alive()):
            shutil.rmtree(root, ignore_errors=True)
    app = FastAPI(title="LEAN-LLM-OPT Demo", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    app.state.store = store
    app.state.deployment = config
    app.add_middleware(BodyLimitMiddleware, limit=MAX_BYTES + 1024 * 1024)

    @app.exception_handler(RequestValidationError)
    async def invalid_body(request, exc):
        return JSONResponse({"detail": "Invalid request fields"}, status_code=422)

    @app.exception_handler(UploadLimitError)
    async def oversized_body(request, exc):
        return JSONResponse({"detail": "Request exceeds upload limits"}, status_code=413)

    @app.middleware("http")
    async def checked_origin(request, call_next):
        host = request.headers.get("host", "")
        api_request = request.url.path.startswith(PREFIX)
        mutation = request.method not in {"GET", "HEAD", "OPTIONS"}
        if config.cloud:
            if request.headers.getlist("host") != [config.authority] or request.url.scheme != "https":
                return JSONResponse({"detail": "Use the configured HTTPS Demo address"}, status_code=400)
        elif not loopback_host(host):
            return Response("A loopback host is required", status_code=400)
        origin = request.headers.get("origin")
        if config.cloud and api_request:
            if (origin and origin != config.public_origin or mutation and origin != config.public_origin
                    or request.headers.get("sec-fetch-site") in {"cross-site", "same-site"}):
                return JSONResponse({"detail": "Use the same-origin Demo page"}, status_code=403)
            identity = request.client.host if request.client else "unknown"
            if not store.allow_request(identity, mutation):
                return JSONResponse({"detail": "Too many requests. Try again shortly."}, status_code=429, headers={"Retry-After": "60"})
        elif api_request and mutation and origin:
            parsed = urlparse(origin)
            if parsed.netloc != host or parsed.scheme not in {"http", "https"}:
                return Response("Cross-origin requests are not allowed", status_code=403)
        try:
            response = await asyncio.wait_for(call_next(request), timeout=config.limits.request_seconds) if config.cloud and api_request else await call_next(request)
        except asyncio.TimeoutError:
            return JSONResponse({"detail": "Request timed out"}, status_code=408)
        if api_request:
            response.headers["Cache-Control"] = "no-store"
            response.headers["X-Content-Type-Options"] = "nosniff"
        elif "Cache-Control" not in response.headers and (request.url.path.endswith("/") or Path(request.url.path).suffix.lower() in {".html", ".js", ".css"}):
            response.headers["Cache-Control"] = "no-cache"
        if config.cloud:
            response.headers["Strict-Transport-Security"] = "max-age=31536000"
            response.headers["Referrer-Policy"] = "same-origin"
            response.headers["X-Frame-Options"] = "DENY"
        return response

    def own_session(sid, request):
        with store.lock:
            session = store.sessions.get(sid)
            if not session or session.owner != request.cookies.get(COOKIE):
                raise HTTPException(404, "Session not found")
            session.touched = time.monotonic()
            return session

    def own_run(rid, request):
        with store.lock:
            run = store.runs.get(rid)
            if not run or run.owner != request.cookies.get(COOKIE):
                raise HTTPException(404, "Run not found")
            store.sessions[run.session_id].touched = time.monotonic()
            return run

    def runtime_status(*, refresh=False):
        if config.cloud:
            return cloud_capabilities()
        runtime = store.executor.health(refresh=refresh)
        return {"status": "ok", "api": True, "execution_available": bool(runtime.get("ready")), "runtime": runtime, "queue": {"concurrency": 1, "waiting": store.queue.qsize(), "max_seconds": MAX_SECONDS}, "limits": {"files": MAX_FILES, "bytes": MAX_BYTES, "preview_rows": 20}, "providers": ["openai", "ollama"]}

    def cloud_capabilities():
        return {"service": "lean-cloud-demo", "protocol": 1, "mode": "cloud", "status": "ok", "api": True,
                "execution_available": bool(store.runtime.get("ready")),
                "runtime": {**store.runtime, "solver": "gurobi", "execution": "docker"},
                "providers": ["openai"], "models": {"openai": "gpt-4.1"}, "embedding_model": "text-embedding-3-small",
                "queue": {"concurrency": 1, "waiting": sum(r.status == "queued" for r in list(store.runs.values())),
                          "max_waiting": config.limits.waiting_runs, "max_seconds": MAX_SECONDS},
                "limits": {"files": MAX_FILES, "bytes": MAX_BYTES, "preview_rows": 20,
                           "session_ttl_seconds": config.limits.session_ttl,
                           "runs_per_session": config.limits.runs_per_session}}

    @app.get(PREFIX + "/capabilities")
    def capabilities():
        if config.cloud:
            return cloud_capabilities()
        return {"service": "lean-local-companion", "protocol": 1, "mode": "local", "status": "ok", "api": True,
                "ollama": ollama_status(),
                "runtime": {"status": "unchecked", "checked": False, "solver": "gurobi", "execution": "docker", "check_path": PREFIX + "/runtime/check"},
                "providers": ["openai", "ollama"],
                "queue": {"concurrency": 1, "waiting": store.queue.qsize(), "max_seconds": MAX_SECONDS},
                "limits": {"files": MAX_FILES, "bytes": MAX_BYTES, "preview_rows": 20}}

    @app.post(PREFIX + "/runtime/check")
    def check_runtime():
        if config.cloud:
            raise HTTPException(404, "Runtime checks are managed by the service")
        return runtime_status(refresh=True)

    @app.get(PREFIX + "/health")
    def health():
        return runtime_status()

    @app.post(PREFIX + "/sessions", status_code=201)
    def new_session(request: Request, response: Response):
        owner = request.cookies.get(COOKIE)
        if not owner or not re.fullmatch(r"[a-f0-9]{64}", owner):
            owner = uuid.uuid4().hex + uuid.uuid4().hex
        store.cleanup()
        with store.lock:
            if config.cloud and (len(store.sessions) >= config.limits.sessions or
                    sum(s.owner == owner for s in store.sessions.values()) >= config.limits.sessions_per_owner):
                raise HTTPException(429, "Conversation limit reached. Delete a previous conversation to continue.")
            sid = uuid.uuid4().hex
            directory = root / sid; directory.mkdir(mode=0o700)
            session = Session(sid, owner, directory)
            store.sessions[sid] = session
        response.set_cookie(COOKIE, owner, httponly=True, samesite="strict", secure=config.cloud or request.url.scheme == "https", path=PREFIX)
        return session_view(session)

    @app.get(PREFIX + "/sessions")
    def list_sessions(request: Request):
        owner = request.cookies.get(COOKIE)
        if not owner:
            return {"sessions": []}
        summaries = []
        with store.lock:
            for session in store.sessions.values():
                if session.owner != owner:
                    continue
                messages = list(session.messages)
                title = next((str(message.get("content", "")) for message in messages if message.get("role") == "user"), "")
                title = clean_payload(" ".join(title.split())[:80])
                last_run = store.runs.get(session.runs[-1]) if session.runs else None
                updated_at = max([session.created_at, *(message.get("created_at", session.created_at) for message in messages), *([last_run.created_at] if last_run else [])])
                summaries.append({"id": session.id, "title": title, "created_at": session.created_at,
                                  "updated_at": updated_at, "run_count": len(session.runs),
                                  "status": last_run.status if last_run else "empty"})
        return {"sessions": sorted(summaries, key=lambda item: (item["updated_at"], item["id"]), reverse=True)}

    @app.get(PREFIX + "/sessions/{sid}")
    def get_session(sid: str, request: Request):
        return session_view(own_session(sid, request))

    @app.delete(PREFIX + "/sessions/{sid}")
    def delete_session(sid: str, request: Request):
        session = own_session(sid, request)
        with store.lock:
            if any(store.runs[rid].status not in TERMINAL for rid in session.runs):
                raise HTTPException(409, "Cancel the active run before deleting this conversation")
            for rid in session.runs:
                store.runs.pop(rid, None)
            store.sessions.pop(sid, None)
            shutil.rmtree(session.directory, ignore_errors=True)
        return {"deleted": sid}

    @app.post(PREFIX + "/sessions/{sid}/files")
    async def upload(sid: str, request: Request):
        session = own_session(sid, request)
        length = request.headers.get("content-length")
        if length:
            try:
                if int(length) > MAX_BYTES + 1024 * 1024:
                    raise HTTPException(413, "Upload exceeds 50 MB")
            except ValueError:
                raise HTTPException(400, "Invalid content length")
        form = await request.form()
        uploads = form.getlist("files") + form.getlist("files[]")
        if not uploads:
            raise HTTPException(400, "Upload at least one CSV using the files field")
        if len(session.files) + len(uploads) > MAX_FILES:
            raise HTTPException(413, "At most 10 CSV files per session")
        prepared = []; size = sum(f["size"] for f in session.files)
        used_names = {f["name"] for f in session.files}
        for item in uploads:
            name = valid_filename(getattr(item, "filename", ""))
            if name in used_names:
                raise HTTPException(409, "A CSV with this filename is already uploaded")
            content = await item.read(MAX_BYTES + 1)
            size += len(content)
            if size > MAX_BYTES:
                raise HTTPException(413, "Session CSV files exceed 50 MB")
            meta = csv_metadata(content, name)
            meta["id"] = uuid.uuid4().hex
            prepared.append((meta, content)); used_names.add(name)
        with store.lock:
            if any(meta["name"] in {f["name"] for f in session.files} for meta, _ in prepared):
                raise HTTPException(409, "A CSV with this filename is already uploaded")
            if len(session.files) + len(prepared) > MAX_FILES or sum(f["size"] for f in session.files) + sum(len(c) for _, c in prepared) > MAX_BYTES:
                raise HTTPException(413, "Session upload limits exceeded")
            store.check_storage(session, sum(len(c) for _, c in prepared))
            for meta, content in prepared:
                directory = session.directory / "files" / meta["id"]; directory.mkdir(parents=True, mode=0o700)
                path = directory / meta["name"]; path.write_bytes(content)
                meta["path"] = str(path)
                session.files.append(meta)
        return {"session_id": sid, "files": session_view(session)["files"]}

    @app.delete(PREFIX + "/sessions/{sid}/files/{fid}")
    def remove_file(sid: str, fid: str, request: Request):
        session = own_session(sid, request)
        with store.lock:
            file = next((f for f in session.files if f["id"] == fid), None)
            if not file:
                raise HTTPException(404, "File not found")
            session.files.remove(file)
            shutil.rmtree(Path(file["path"]).parent, ignore_errors=True)
        return {"session_id": sid, "files": session_view(session)["files"]}

    @app.post(PREFIX + "/sessions/{sid}/examples/{example_id}")
    def example(sid: str, example_id: str, request: Request):
        session = own_session(sid, request)
        from .examples import get_example
        try:
            data = get_example(example_id)
        except (ValueError, KeyError):
            raise HTTPException(404, "Example not found")
        with store.lock:
            store.check_storage(session, sum(len(f["content"].encode("utf-8")) for f in data["files"]))
            for f in session.files:
                shutil.rmtree(Path(f["path"]).parent, ignore_errors=True)
            session.files = []
            for f in data["files"]:
                name = valid_filename(f["name"])
                content = f["content"].encode("utf-8")
                meta = csv_metadata(content, name); meta["id"] = uuid.uuid4().hex
                directory = session.directory / "files" / meta["id"]; directory.mkdir(parents=True, mode=0o700)
                path = directory / name; path.write_bytes(content); meta["path"] = str(path)
                session.files.append(meta)
        return {**session_view(session), "example": {k: v for k, v in data.items() if k != "files"}, "query": data["query"]}

    @app.post(PREFIX + "/sessions/{sid}/messages", status_code=202)
    def message(sid: str, body: MessageBody, request: Request):
        session = own_session(sid, request)
        if body.provider not in {"openai", "ollama"} or body.language not in {"zh", "en"}:
            raise HTTPException(400, "Unsupported provider or language")
        if config.cloud and (body.provider != "openai" or body.model not in {"", "gpt-4.1"}):
            raise HTTPException(400, "This service uses OpenAI GPT-4.1")
        if body.provider != "ollama" and not body.api_key.strip():
            raise HTTPException(400, "An API key is required for this provider")
        if not body.content.strip():
            raise HTTPException(400, "Message is empty")
        if config.cloud and not store.runtime.get("ready"):
            raise HTTPException(503, "The solver is starting or unavailable. Try again shortly.")
        with store.lock:
            if any(store.runs[rid].status not in TERMINAL for rid in session.runs):
                raise HTTPException(409, "This session already has an active run")
            if config.cloud:
                if len(body.content) > 20000:
                    raise HTTPException(413, "Question exceeds 20000 characters")
                if len(session.runs) >= config.limits.runs_per_session:
                    raise HTTPException(429, "Conversation run limit reached. Start a new conversation.")
                if len(store.runs) >= config.limits.runs:
                    raise HTTPException(429, "Run storage is full. Delete a previous conversation or try later.")
                active = [r for r in store.runs.values() if r.status not in TERMINAL]
                if any(r.owner == session.owner for r in active):
                    raise HTTPException(409, "You already have an active run")
                if len(active) >= config.limits.waiting_runs + 1:
                    raise HTTPException(429, "The run queue is full. Try again shortly.")
                store.check_storage(session, sum(f["size"] for f in session.files))
            # Credentials belong in the provider client only. If a key was also
            # pasted into chat, remove that exact value before retaining or
            # forwarding the task/history. Other task text stays unchanged.
            secret = body.api_key.strip()
            if secret and any(secret.encode("utf-8") in Path(f["path"]).read_bytes() for f in session.files):
                raise HTTPException(400, "Remove the configured API key from uploaded CSV data before running")
            query = redact_credential(body.content.strip(), secret)
            if secret:
                for item in session.messages:
                    if isinstance(item.get("content"), str):
                        item["content"] = redact_credential(item["content"], secret)
            rid = uuid.uuid4().hex
            directory = session.directory / "runs" / rid
            inputs = directory / "inputs"; outputs = directory / "outputs"
            inputs.mkdir(parents=True, mode=0o755); outputs.mkdir(mode=0o777)
            files = []
            for f in session.files:
                destination = inputs / f["name"]
                shutil.copyfile(f["path"], destination); destination.chmod(0o644)
                files.append({"id": f["id"], "name": f["name"], "path": str(destination)})
            prior = redact_credential(prior_result(session, store), secret)
            model = body.model or ("gpt-4.1" if body.provider == "openai" else "gpt-oss:20b")
            context = {"run_id": rid, "query": query, "messages": list(session.messages), "provider": body.provider, "model": model, "api_key": secret if body.provider == "openai" else "", "language": body.language, "files": files, "input_dir": str(inputs), "output_dir": str(outputs), "prior_artifacts": prior or {}}
            context["deployment_mode"] = config.mode
            run = Run(rid, sid, session.owner, directory, context, limits=store.limits)
            context["deadline_monotonic"] = run.started + MAX_SECONDS
            store.runs[rid] = run; session.runs.append(rid)
            session.messages.append({"id": uuid.uuid4().hex, "role": "user", "content": query, "run_id": rid, "created_at": now()})
            run.emit("run", "queued", {"position": store.queue.qsize() + 1})
            store.queue.put(rid)
        return {"run_id": rid, "session_id": sid, "status": run.status, "run": run_view(run)}

    @app.get(PREFIX + "/runs/{rid}")
    def get_run(rid: str, request: Request):
        return run_view(own_run(rid, request))

    @app.get(PREFIX + "/runs/{rid}/events")
    async def events(rid: str, request: Request, after: int = 0):
        run = own_run(rid, request)
        try:
            cursor = max(0, after, int(request.headers.get("last-event-id", "0")))
        except ValueError:
            raise HTTPException(400, "Invalid event cursor")
        if cursor > run.sequence:
            raise HTTPException(400, "Event cursor is beyond this run")
        with store.lock:
            if config.cloud and (store.sse_counts.get(run.owner, 0) >= config.limits.sse_per_owner
                                 or sum(store.sse_counts.values()) >= config.limits.sse_total):
                raise HTTPException(429, "Too many open event streams")
            store.sse_counts[run.owner] = store.sse_counts.get(run.owner, 0) + 1
        async def stream():
            nonlocal cursor
            opened = time.monotonic()
            try:
                while True:
                    if await request.is_disconnected() or config.cloud and time.monotonic() - opened >= config.limits.sse_seconds:
                        break
                    with run.condition:
                        batch = [event for event in run.events if event["seq"] > cursor]
                        terminal = run.status in TERMINAL
                        last_seq = run.sequence
                    # Sequence IDs are monotonic even after bounded retention.
                    # Missing old token events do not alter the saved result;
                    # terminal events always point to GET /runs/id for recovery.
                    for event in batch:
                        yield f"id: {event['seq']}\ndata: {json.dumps(event, ensure_ascii=False)}\n\n"
                        cursor = event["seq"]
                    if terminal and cursor >= last_seq:
                        break
                    if not batch:
                        yield ": keep-alive\n\n"
                    await asyncio.sleep(0.2)
            finally:
                with store.lock:
                    store.sse_counts[run.owner] -= 1
                    if not store.sse_counts[run.owner]:
                        store.sse_counts.pop(run.owner, None)
        return StreamingResponse(stream(), media_type="text/event-stream", headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

    @app.post(PREFIX + "/runs/{rid}/cancel")
    def cancel(rid: str, request: Request):
        run = own_run(rid, request)
        with store.lock:
            if run.status not in TERMINAL and not run.cancel.is_set():
                run.cancel.set()
                if run.status == "queued":
                    run.context.pop("api_key", None)
                    run.terminate("cancelled", {})
                else:
                    run.emit("run", "cancellation_requested", {})
        return run_view(run)

    @app.get(PREFIX + "/runs/{rid}/artifacts/{name}")
    def artifact(rid: str, name: str, request: Request):
        run = own_run(rid, request)
        path = run.artifacts.get(name)
        if not path or not path.is_file() or path.is_symlink() or path.resolve().parent != (run.directory / "outputs").resolve():
            raise HTTPException(404, "Artifact not found")
        return FileResponse(path, filename=name, headers={"X-Content-Type-Options": "nosniff"})

    website = Path(website_root or Path(__file__).resolve().parents[1] / "website")
    if website.is_dir():
        if config.cloud:
            @app.get("/demo/", response_class=HTMLResponse)
            @app.get("/demo/index.html", response_class=HTMLResponse)
            def cloud_demo():
                # Only trusted server configuration selects the hosted runtime.
                # No query, credential, session or forwarded-host interpolation.
                page = website / "demo" / "index.html"
                if not page.is_file():
                    raise HTTPException(404, "Demo page not found")
                markup = page.read_text(encoding="utf-8")
                def mark(match):
                    attributes = re.sub(r"\sdata-deployment\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+)", "", match.group(1), flags=re.I)
                    return '<html data-deployment="cloud"' + attributes + '>'
                markup, count = re.subn(r"<html\b([^>]*)>", mark, markup, count=1, flags=re.I)
                if count != 1:
                    raise HTTPException(503, "Demo page is unavailable")
                return HTMLResponse(markup, headers={"Cache-Control": "no-store"})
        app.mount("/", StaticFiles(directory=website, html=True), name="website")
    return app
