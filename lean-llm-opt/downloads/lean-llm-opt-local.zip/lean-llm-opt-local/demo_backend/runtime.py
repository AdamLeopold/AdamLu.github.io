"""Docker-only execution with one Gurobi environment per private worker owner."""
from __future__ import annotations

import ast
import atexit
import io
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid

IMAGE = "lean-llm-opt-demo:local"
ALLOWED_IMPORTS = {"gurobipy", "pandas", "numpy", "math", "itertools", "collections", "json", "csv", "re", "statistics", "decimal", "sys"}
FORBIDDEN_NAMES = {"exec", "eval", "compile", "__import__", "getattr", "setattr", "delattr", "globals", "locals", "vars", "input", "breakpoint", "help", "super"}
FORBIDDEN_ATTRIBUTES = {"system", "popen", "spawn", "load", "loads", "read_pickle", "to_pickle", "load_library", "ctypeslib", "modules", "environ", "getenv", "os", "socket", "fromfile", "memmap", "read", "readParams", "getEnv", "getParam", "getParamInfo", "Env", "open_code", "FileIO", "settrace", "setprofile", "setrecursionlimit", "setswitchinterval", "mro", "optimizeAsync"}
SENSITIVE_CONFIGURATION = re.compile(r"\bwls(?:accessid|secret|token|config)?\b|\blicenseid\b|\bserverpassword\b|\bcomputepassword\b|\btokenserver\b", re.I)


def validate_code(code: str) -> None:
    if not isinstance(code, str) or not code.strip() or len(code) > 1_000_000:
        raise ValueError("Empty or oversized solver code")
    tree = ast.parse(code)
    module_aliases = {"gp", "pd", "np", "GRB"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            module_aliases.update(alias.asname or alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            module_aliases.update(alias.asname or alias.name for alias in node.names)
    changed = True
    while changed:
        changed = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Name) and node.value.id in module_aliases:
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id not in module_aliases:
                        module_aliases.add(target.id); changed = True
    def root_name(node):
        while isinstance(node, (ast.Attribute, ast.Subscript)):
            node = node.value
        return node.id if isinstance(node, ast.Name) else None
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and node.attr == "optimize" and isinstance(node.ctx, (ast.Store, ast.Del)):
            raise ValueError("Solver code cannot replace the controlled optimizer")
        if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign, ast.Delete)):
            targets = node.targets if isinstance(node, (ast.Assign, ast.Delete)) else [node.target]
            for target in targets:
                if isinstance(target, (ast.Attribute, ast.Subscript)) and root_name(target) in module_aliases:
                    raise ValueError("Solver code cannot modify imported modules")
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
            if any(name.split(".")[0] not in ALLOWED_IMPORTS for name in names):
                raise ValueError("Solver code contains an unsupported import")
            if isinstance(node, ast.ImportFrom) and any(a.name in FORBIDDEN_ATTRIBUTES for a in node.names):
                raise ValueError("Solver code contains an unsupported import")
        if isinstance(node, ast.Name) and (node.id in FORBIDDEN_NAMES or node.id.startswith("__")):
            raise ValueError("Solver code contains an unsupported operation")
        if isinstance(node, ast.Attribute) and (node.attr.startswith("_") or node.attr in FORBIDDEN_ATTRIBUTES):
            raise ValueError("Solver code contains an unsupported attribute")
        if isinstance(node, ast.Attribute) and SENSITIVE_CONFIGURATION.search(node.attr):
            raise ValueError("Solver code cannot access license configuration")
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            value = node.value.lower()
            if SENSITIVE_CONFIGURATION.search(value) or any(prefix in value for prefix in ("http://", "https://", "ftp://", "/licenses", "/proc/", "/etc/")):
                raise ValueError("Solver code may access only the supplied local data")


def make_file_guard(original_open, input_root=Path("/inputs"), output_root=Path("/outputs")):
    input_root = Path(input_root).resolve(); output_root = Path(output_root).resolve()
    def guarded_open(file, mode="r", *args, **kwargs):
        path = Path(file).resolve(); writable = any(flag in mode for flag in "wax+")
        if writable and not path.is_relative_to(output_root):
            raise PermissionError("Write only to /outputs")
        if not writable and not (path.is_relative_to(input_root) or path.is_relative_to(output_root)):
            raise PermissionError("Read only supplied data")
        return original_open(file, mode, *args, **kwargs)
    return guarded_open


def _result(status="error", **kw):
    return {"status": status, "objective": None, "variables": [], "stdout": "", "stderr": "", "artifacts": [], **kw}


def _environment_failure(exc):
    number = getattr(exc, "errno", None); number = number if isinstance(number, int) else None
    message = str(exc).lower()
    reason = "license_session_limit" if any(s in message for s in ("overage", "too many sessions", "active sessions", "baseline")) else "network" if any(s in message for s in ("network", "connect", "resolve", "timeout")) else "license_expired" if "expired" in message else "initialization"
    return _result("execution_unavailable", execution_started=False, environment_error_code=number, environment_error_reason=reason, error="Isolated solver initialization failed (" + type(exc).__name__ + (f", code {number}" if number is not None else "") + ")")


def _controlled_model_class(base):
    class ControlledModel(base):
        def optimize(self, *args, **kwargs):
            threads = int(self.Params.Threads)
            self.Params.Threads = 2 if threads <= 0 else min(2, threads)
            self.Params.TimeLimit = min(180.0, float(self.Params.TimeLimit))
            return base.optimize(self, *args, **kwargs)
    return ControlledModel


class _LaunchFailure(Exception):
    def __init__(self, result):
        self.result = result


class _WorkerProcess:
    def __init__(self, executor, owner=None, cancelled=None):
        self.executor = executor; self.owner = owner
        self.name = "lean-demo-" + uuid.uuid4().hex
        self.directory = tempfile.TemporaryDirectory(prefix="lean-worker-private-", ignore_cleanup_errors=True)
        root = Path(self.directory.name); root.chmod(0o700)
        self.inputs = root / "inputs"; self.inputs.mkdir(mode=0o755)
        self.outputs = root / "outputs"; self.outputs.mkdir(mode=0o777)
        self.outputs.chmod(0o777)
        self.frames = queue.Queue(maxsize=8)
        self.proc = None
        try:
            self.proc = subprocess.Popen(executor._docker_command(self.name, self.inputs, self.outputs), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
            self.reader = threading.Thread(target=self._read, daemon=True); self.reader.start()
            frame = self.wait("ready", timeout=45, cancelled=cancelled, started=False)
            if not frame.get("ready"):
                raise _LaunchFailure(frame.get("result") or _result("execution_unavailable", execution_started=False, error="Isolated worker could not initialize"))
        except BaseException:
            self.close(force=True)
            raise

    def _read(self):
        try:
            for line in self.proc.stdout:
                if len(line) > 5_000_000:
                    continue
                try:
                    frame = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if isinstance(frame, dict) and frame.get("type") in {"ready", "result"}:
                    self.frames.put(frame)
        except (OSError, ValueError):
            pass

    def wait(self, kind, *, timeout, cancelled, started, job_id=None):
        deadline = time.monotonic() + timeout
        while True:
            if cancelled and cancelled():
                self.close(force=True)
                return {"result": _result("cancelled", execution_started=started, error="Execution cancelled")}
            if time.monotonic() >= deadline:
                self.close(force=True)
                return {"result": _result("time_limit" if started else "execution_unavailable", execution_started=started, error="Isolated worker reached its time limit")}
            try:
                frame = self.frames.get(timeout=0.1)
                if frame.get("type") == kind and (job_id is None or frame.get("job_id") == job_id):
                    return frame
            except queue.Empty:
                if self.proc.poll() is not None:
                    return {"result": _result("error" if started else "execution_unavailable", execution_started=started, error="Isolated worker stopped unexpectedly")}

    def call(self, code, *, kind, timeout, cancelled):
        if cancelled and cancelled():
            return _result("cancelled", execution_started=False, error="Execution cancelled")
        job_id = uuid.uuid4().hex
        try:
            self.proc.stdin.write(json.dumps({"job_id": job_id, "code": code, "kind": kind}) + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError):
            return _result("execution_unavailable", execution_started=False, error="Could not contact the isolated worker")
        frame = self.wait("result", timeout=timeout, cancelled=cancelled, started=True, job_id=job_id)
        return frame.get("result") or _result(error="The isolated worker did not return a valid result")

    def close(self, force=False):
        proc = self.proc
        if proc is not None and proc.poll() is None:
            if not force:
                try:
                    proc.stdin.close(); proc.wait(timeout=3)
                except (OSError, ValueError, subprocess.TimeoutExpired):
                    force = True
            if force and proc.poll() is None:
                try:
                    subprocess.run([self.executor.docker, "rm", "--force", self.name], capture_output=True, timeout=6)
                except (OSError, subprocess.TimeoutExpired):
                    pass
                if proc.poll() is None:
                    proc.kill(); proc.wait(timeout=3)
                # Cover a race between Docker's creation and cancellation.
                try:
                    subprocess.run([self.executor.docker, "rm", "--force", self.name], capture_output=True, timeout=6)
                except (OSError, subprocess.TimeoutExpired):
                    pass
        if hasattr(self, "directory"):
            self.directory.cleanup()


class DockerExecutor:
    def __init__(self, image=IMAGE, license_path=None, timeout=180, docker=None):
        self.image = image
        self.license_path = Path(license_path or os.environ.get("GRB_LICENSE_FILE") or Path.home() / "gurobi.lic").expanduser().resolve()
        self.timeout = min(180, max(1, int(timeout))); self.docker = docker or shutil.which("docker")
        self._health = None; self._health_at = 0.0
        self._probe_lock = threading.Lock(); self._worker_lock = threading.RLock()
        self._worker = None; self._closed = False
        atexit.register(self.close)

    def _docker_command(self, name, inputs, outputs):
        return [self.docker, "run", "--rm", "--name", name, "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--pids-limit=128", "--cpus=2", "--memory=2g", "--memory-swap=2g", "--user=1000:1000", "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", "--mount", f"type=bind,src={Path(inputs).resolve()},dst=/inputs,readonly", "--mount", f"type=bind,src={Path(outputs).resolve()},dst=/outputs", "--mount", f"type=bind,src={self.license_path},dst=/licenses/gurobi.lic,readonly", "--workdir=/inputs", "--network=bridge", "--interactive", self.image, "--serve"]

    def close(self):
        with self._worker_lock:
            self._closed = True
            if self._worker:
                self._worker.close(); self._worker = None

    def health(self, refresh=False):
        with self._probe_lock:
            cache_seconds = 30 if self._health and self._health.get("ready") else 300 if self._health and self._health.get("environment_error_reason") == "license_session_limit" else 5
            if self._health is not None and not refresh and time.monotonic() - self._health_at < cache_seconds:
                return dict(self._health)
            state = {"ready": False, "docker": False, "image": False, "license": self.license_path.is_file(), "solver": False}
            if not self.docker:
                state["reason"] = "Docker is not installed"
            else:
                try:
                    state["docker"] = subprocess.run([self.docker, "info", "--format", "{{.ServerVersion}}"], capture_output=True, timeout=8).returncode == 0
                    if not state["docker"]:
                        state["reason"] = "Docker Desktop is not running or its socket is inaccessible"
                    else:
                        state["image"] = subprocess.run([self.docker, "image", "inspect", self.image], capture_output=True, timeout=8).returncode == 0
                        if not state["image"]: state["reason"] = "The isolated solver image has not been built"
                        elif not state["license"]: state["reason"] = "A Gurobi license file is required"
                        else:
                            with tempfile.TemporaryDirectory(prefix="lean-probe-") as td:
                                inputs = Path(td) / "inputs"; inputs.mkdir()
                                solved = self._execute("import gurobipy as gp\nfrom gurobipy import GRB\nm=gp.Model('health')\nx=m.addVar(lb=0,name='x')\nm.addConstr(x>=1)\nm.setObjective(x,GRB.MINIMIZE)\nm.optimize()\n", inputs, Path(td) / "outputs", None)
                            state["solver"] = solved.get("status") == "optimal" and abs((solved.get("objective") or 0) - 1) < 1e-8
                            state["ready"] = state["solver"]
                            if not state["ready"]:
                                state["reason"] = "The isolated Gurobi license/solver probe failed"
                                for field in ("environment_error_code", "environment_error_reason"):
                                    if solved.get(field) is not None: state[field] = solved[field]
                except (OSError, subprocess.TimeoutExpired):
                    state["reason"] = "Docker did not respond to its health check"
            self._health = state; self._health_at = time.monotonic()
            return dict(state)

    def execute(self, code, input_dir, *, output_dir=None, cancelled=None, kind="solve", worker_key=None):
        try: validate_code(code)
        except (ValueError, SyntaxError) as exc: return _result(error=str(exc))
        if cancelled and cancelled(): return _result("cancelled")
        state = self.health()
        if cancelled and cancelled(): return _result("cancelled", execution_started=False)
        if not state.get("ready") and state.get("environment_error_reason") != "license_session_limit" and all(state.get(key) for key in ("docker", "image", "license")):
            state = self.health(refresh=True)
        if not state.get("ready"):
            return _result("execution_unavailable", error="Isolated execution unavailable; check /api/demo/health. Host execution is disabled.", environment_error_code=state.get("environment_error_code"), environment_error_reason=state.get("environment_error_reason"))
        output = Path(output_dir) if output_dir else Path(tempfile.mkdtemp(prefix="lean-result-"))
        result = self._execute(code, Path(input_dir), output, cancelled, kind=kind, worker_key=worker_key)
        if result.get("status") == "execution_unavailable" and result.get("execution_started") is False and result.get("environment_error_reason") != "license_session_limit" and not (cancelled and cancelled()):
            result = self._execute(code, Path(input_dir), output, cancelled, kind=kind, worker_key=worker_key)
        if result.get("status") == "execution_unavailable":
            with self._probe_lock:
                self._health = {**state, "ready": False, "solver": False, "reason": "The isolated worker is unavailable"}
                for field in ("environment_error_code", "environment_error_reason"):
                    if result.get(field) is not None: self._health[field] = result[field]
                self._health_at = time.monotonic()
        return result

    @staticmethod
    def _clear(directory):
        for path in directory.iterdir():
            if path.is_dir() and not path.is_symlink(): shutil.rmtree(path)
            else: path.unlink()

    def _launch_worker(self, owner, cancelled=None):
        return _WorkerProcess(self, owner, cancelled=cancelled)

    def _execute(self, code, input_dir, output_dir, cancelled, kind="solve", worker_key=None):
        with self._worker_lock:
            if cancelled and cancelled(): return _result("cancelled", execution_started=False)
            if self._closed: return _result("execution_unavailable", execution_started=False, error="Isolated executor is closed")
            worker = self._worker
            if worker and (worker.proc.poll() is not None or (worker_key is not None and worker.owner not in {None, worker_key})):
                worker.close(); self._worker = None; worker = None
            if worker is None:
                try:
                    worker = self._launch_worker(worker_key, cancelled=cancelled); self._worker = worker
                except _LaunchFailure as exc: return exc.result
                except (OSError, subprocess.TimeoutExpired): return _result("execution_unavailable", execution_started=False, error="Could not start the isolated worker")
            if worker_key is not None: worker.owner = worker_key
            try:
                output_dir.mkdir(parents=True, exist_ok=True); output_dir.chmod(0o777)
                self._clear(worker.inputs); self._clear(worker.outputs)
                for path in input_dir.iterdir():
                    if path.is_file() and not path.is_symlink() and path.suffix.lower() == ".csv":
                        target = worker.inputs / path.name; shutil.copyfile(path, target); target.chmod(0o644)
                if cancelled and cancelled(): return _result("cancelled", execution_started=False)
                result = worker.call(code, kind=kind, timeout=self.timeout, cancelled=cancelled)
                if worker.proc.poll() is not None:
                    worker.close(); self._worker = None
                else:
                    for path in worker.outputs.iterdir():
                        if path.is_file() and not path.is_symlink() and path.resolve().parent == worker.outputs.resolve() and path.stat().st_size <= 50 * 1024 * 1024:
                            shutil.copyfile(path, output_dir / path.name)
                return result
            except BaseException:
                worker.close(force=True); self._worker = None
                raise
            finally:
                if self._worker is worker:
                    try:
                        self._clear(worker.inputs); self._clear(worker.outputs)
                    except OSError:
                        worker.close(force=True); self._worker = None


class _BoundedText(io.StringIO):
    def write(self, value):
        room = 2_000_000 - self.tell()
        if room > 0: super().write(value[:room])
        return len(value)
    def close(self):
        # A generated program must not close the worker's capture/protocol stream.
        pass


class _LicensedRuntime:
    def __init__(self):
        import builtins
        import importlib
        import math
        import socket
        import gurobipy as gp
        import pandas as pd
        import numpy as np
        from gurobipy import GRB
        self.gp, self.pd, self.np, self.GRB, self.math = gp, pd, np, GRB, math
        self.modules = [importlib.import_module(name) for name in sorted(ALLOWED_IMPORTS)] + [builtins, io, socket]
        self.original_open = builtins.open
        self.original_io_open = io.open
        self.original_import = builtins.__import__
        self.original_socket = socket.socket
        self.original_model = gp.Model
        self.controlled_model = _controlled_model_class(self.original_model)
        self.status_codes = {GRB.OPTIMAL: "optimal", GRB.INFEASIBLE: "infeasible", GRB.UNBOUNDED: "unbounded", GRB.TIME_LIMIT: "time_limit"}
        self.isfinite = math.isfinite
        self.env = gp.Env(empty=True); self.env.setParam("OutputFlag", 0); self.env.start()
        def safe_import(name, *args, **kwargs):
            if name.split(".")[0] not in ALLOWED_IMPORTS: raise ImportError("Unsupported solver import")
            return self.original_import(name, *args, **kwargs)
        self.safe_import = safe_import

    def close(self):
        self.env.dispose()

    def run(self, payload):
        import contextlib
        import builtins
        import socket
        buffer = _BoundedText(); created = []
        result = _result()
        snapshots = [(module, dict(vars(module))) for module in self.modules]
        constants = {name: value for name, value in vars(self.GRB).items() if not name.startswith("_")}
        try:
            code = payload["code"]; validate_code(code)
            safe_open = make_file_guard(self.original_open)
            builtins.open = safe_open; io.open = safe_open
            def blocked_socket(*args, **kwargs): raise PermissionError("Python network access is disabled")
            socket.socket = blocked_socket
            def make_model(*args, **kwargs):
                kwargs["env"] = self.env
                model = self.controlled_model(*args, **kwargs)
                model.Params.OutputFlag = 0; model.Params.TimeLimit = 180; model.Params.Threads = 2
                created.append(model); return model
            self.gp.Model = make_model
            namespace = {"__builtins__": {**builtins.__dict__, "__import__": self.safe_import, "open": safe_open}, "gp": self.gp, "GRB": self.GRB, "pd": self.pd, "np": self.np}
            with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
                exec(compile(code, "generated-model.py", "exec"), namespace)
                if not created and payload.get("kind") == "data": result = _result("completed")
                elif not created: raise ValueError("Generated code did not create a Gurobi model")
                else:
                    model = created[-1]
                    status = self.status_codes.get(model.Status, "solver_stopped")
                    objective = float(model.ObjVal) if model.SolCount else None
                    if objective is not None and not self.isfinite(objective): objective = None
                    variables = [{"name": v.VarName, "value": float(v.X)} for v in model.getVars()[:20000]] if model.SolCount else []
                    model.write("/outputs/model.lp")
                    result = _result(status, solver_status_code=int(model.Status), objective=objective, variables=variables, artifacts=["model.lp"])
            result["stdout"] = buffer.getvalue()
        except BaseException as exc:
            diagnostic = str(exc)[:2000]
            if buffer.getvalue().strip(): diagnostic += "\nProgram output: " + buffer.getvalue()[-4000:]
            result = _result(error=f"{type(exc).__name__}: {diagnostic}", stderr=buffer.getvalue()[-8000:])
        finally:
            for model in created:
                try: model.dispose()
                except Exception: pass
            for module, values in snapshots:
                current = vars(module)
                for name in list(current):
                    if name not in values: del current[name]
                current.update(values)
            self.gp.Model = self.original_model
            for name in list(vars(self.GRB)):
                if not name.startswith("_") and name not in constants: delattr(self.GRB, name)
            for name, value in constants.items():
                if getattr(self.GRB, name, None) is not value: setattr(self.GRB, name, value)
            builtins.open = self.original_open; io.open = self.original_io_open
            builtins.__import__ = self.original_import; socket.socket = self.original_socket
        return result


def _worker_main(persistent=False):
    import contextlib
    import sys
    output = sys.stdout
    def send(frame):
        print(json.dumps(frame, allow_nan=False), file=output, flush=True)
    try:
        with contextlib.redirect_stdout(_BoundedText()), contextlib.redirect_stderr(_BoundedText()):
            runtime = _LicensedRuntime()
    except BaseException as exc:
        result = _environment_failure(exc)
        send({"type": "ready", "ready": False, "result": result} if persistent else result)
        return
    try:
        if persistent:
            send({"type": "ready", "ready": True})
            for line in sys.stdin:
                try:
                    payload = json.loads(line)
                    result = runtime.run(payload)
                    send({"type": "result", "job_id": payload.get("job_id"), "result": result})
                except (ValueError, TypeError):
                    break
        else:
            send(runtime.run(json.load(sys.stdin)))
    finally:
        runtime.close()


if __name__ == "__main__":
    import sys
    if sys.argv[1:] in (["--worker"], ["--serve"]):
        _worker_main(persistent=sys.argv[1:] == ["--serve"])
