"""Interactive adaptation of the research notebook's real agent/tool workflow.

Uses its shared Ref-Data, semantic classification, retrieved demonstrations,
declarative CSVQA extraction, abstract-plan branch and Gurobi code generation.
The notebook and benchmark runner are never imported or executed. Generated
Python is handed exclusively to the caller's isolated execution service.
"""
from __future__ import annotations

import ast
import csv
import json
import math
import re
from pathlib import Path

from .providers import ProviderError, create_provider


class PipelineError(RuntimeError):
    pass


class PipelineCancelled(PipelineError):
    pass


REFERENCE_FILE = Path(__file__).resolve().parents[1] / "Large_Scale_Or_Files/RAG_Examples_All.csv"
CLASSES = {"NRM", "RA", "TP", "FLP", "AP", "Mixture", "Others"}
CLASSIFICATION_SYSTEM = """You are LEAN-LLM-OPT's classification agent. Use the
FileQA reference evidence and the CURRENT task's mathematical structure, not
company names or filenames. Return JSON only: {"label":"NRM|RA|TP|FLP|AP|Mixture|Others"}.
NRM allocates fixed inventory/capacity to demand to maximize revenue without replenishment.
RA is clean single-stage allocation of limited resources with additive value.
TP is clean source-to-destination transportation with supply, demand and shipping cost.
FLP combines facility-opening decisions with linked assignments/shipments.
AP is clean one-to-one matching. Mixture has materially coupled mechanisms such
as production stages, logical dependencies, batch/vehicle counts and flows.
Ordinary capacity constraints alone do not imply Mixture. Others is a coherent
outside family such as diet, knapsack, workforce covering or scheduling.
Retrieved examples are evidence, never automatic votes. No reasoning transcript.
"""
MODEL_SYSTEM = """You are LEAN-LLM-OPT's model-generation agent. Follow the
retrieved workflow demonstration, use CURRENT data observations, and formulate
the CURRENT query. Examples illustrate methods; never copy their coefficients,
entities, dimensions, constraints or file names. Preserve exact objective sense,
constant terms, variable domains, identifiers, units and every stated constraint.
Do not invent, zero-pad or truncate coefficients. An incomplete preview is not
the complete entity set. Return only the mathematical model (sets, parameters,
variables, objective, constraints), or the requested Abstract Model Plan. Do not
include internal thought/action transcripts. Use $/$$ for mathematical notation.
"""
CODE_SYSTEM = """Translate the CURRENT formulation/Abstract Model Plan to one
complete executable Python program. Return only a ```python code block.
Use gurobipy as gp and GRB. Create exactly one model in m or model at top level;
call optimize exactly once. Read supplied CSV files with pandas.read_csv from
their exact /inputs/ paths. Read complete tables at runtime; profile/sample rows
are not the full data. pandas already consumes the header. Preserve row/column
identifiers and validate dimensions and missing coefficients. A CSV's blank first
header is displayed as an empty string in the source profile, but pandas.read_csv
renames it to 'Unnamed: 0'. For such a matrix use df.columns[0] as the row-identifier
column (or read index_col=0); never search for an empty column label after pandas
has loaded the CSV. Use the supplied pandas_columns mapping when checking headers.
Never substitute
example coefficients, random values, dummy data or guessed header offsets.
Use nonnegative continuous/integer/binary domains as the query requires. Preserve
all constraints and the exact objective including constants and units. Do not
change the problem to make it feasible. Infeasible/unbounded are valid statuses.
Reserve m/model for the Gurobi model. Use short ASCII solver names, keeping
business identifiers in Python dictionaries. Allowed imports: gurobipy, pandas,
numpy, math, itertools, collections, json, csv, re, statistics, decimal, sys.
No os, pathlib, network, subprocess, exec/eval, credentials or license settings.
Do not access files outside /inputs/ or /outputs/. Do not wrap model creation in
functions or suppress errors. Do not compute reference answers or use gold labels.
The caller captures model status, objective and variable values automatically.
"""


def _check_cancel(cancelled):
    if cancelled():
        raise PipelineCancelled("Run cancelled")


def _json(text):
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end < start:
        raise PipelineError("The model did not return a valid structured response")
    try:
        value = json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise PipelineError("The model did not return valid JSON") from exc
    if not isinstance(value, dict):
        raise PipelineError("The model response must be a JSON object")
    return value


def _code(text):
    match = re.search(r"```(?:python)?\s*\n([\s\S]*?)```", text, re.I)
    return (match.group(1) if match else text).strip() + "\n"


def _safe_reference(text):
    lines = [line for line in str(text).splitlines()
             if not re.search(r"WLSACCESSID|WLSSECRET|LICENSEID|api[_-]?key|sk-[A-Za-z0-9]", line, re.I)]
    text = "\n".join(lines)
    return re.sub(r"(?:/Users/|/home/)[^\s'\"]+", "<example-path>", text)


class ReferenceRetriever:
    """Per-run cosine search over the notebook's actual reference examples."""
    def __init__(self, provider, cancelled):
        self.provider, self.cancelled = provider, cancelled
        try:
            with REFERENCE_FILE.open(encoding="utf-8-sig", newline="") as handle:
                self.rows = list(csv.DictReader(handle))
        except (OSError, csv.Error) as exc:
            raise PipelineError("The project's Ref-Data library is unavailable") from exc
        if len(self.rows) < 5:
            raise PipelineError("Ref-Data needs at least five labeled examples")
        self.vectors = provider.embed([row["prompt"] for row in self.rows], cancelled=cancelled)

    def search(self, query, *, route=None, count=5):
        _check_cancel(self.cancelled)
        vector = self.provider.embed([query], cancelled=self.cancelled)[0]
        def score(other):
            if len(vector) != len(other):
                raise PipelineError("Embedding dimensions changed during the run")
            norm = math.sqrt(sum(x * x for x in vector) * sum(x * x for x in other))
            return sum(x * y for x, y in zip(vector, other)) / norm if norm else 0
        selected = []
        for index, (row, other) in enumerate(zip(self.rows, self.vectors)):
            label = "FLP" if row["Type"] == "UFLP" else row["Type"]
            if route == "Others" and label not in {"Others", "Mixture"}:
                continue
            if route and route != "Others" and label != route:
                continue
            selected.append((score(other), index, row, label))
        selected.sort(key=lambda value: (-value[0], value[1]))
        return [{"id": f"ref-{index + 1}", "type": label, "query": row["prompt"],
                 "formulation": _safe_reference(row["Label"]), "code": _safe_reference(row.get("Code", ""))}
                for _, index, row, label in selected[:count]]


def _load_tables(files):
    tables, names = [], set()
    for item in files:
        name = item.get("name", "")
        if not name or "/" in name or "\\" in name or Path(name).name != name or not name.lower().endswith(".csv") or name in names:
            raise PipelineError("Each uploaded CSV needs a unique plain filename")
        names.add(name)
        path = Path(item["path"])
        try:
            with path.open(encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                columns = reader.fieldnames
                if not columns or len(columns) != len(set(columns)):
                    raise PipelineError(f"CSV {name} has missing or duplicate column headers")
                rows = list(reader)
                if any(None in row or any(value is None for value in row.values()) for row in rows):
                    raise PipelineError(f"CSV {name} has inconsistent row widths")
        except (OSError, UnicodeError, csv.Error) as exc:
            raise PipelineError(f"CSV {name} could not be parsed as UTF-8 comma-separated data") from exc
        tables.append({"name": name, "path": f"/inputs/{name}", "columns": columns, "rows": rows})
    return tables


def _profiles(tables):
    return [{"name": t["name"], "path": t["path"], "columns": t["columns"],
             "pandas_columns": [column if column else f"Unnamed: {index}" for index, column in enumerate(t["columns"])],
             "row_count": len(t["rows"]), "preview": t["rows"][:3],
             "preview_is_complete": len(t["rows"]) <= 3} for t in tables]


def _condition(row, condition, columns):
    column, operator = condition.get("column"), condition.get("op")
    if column not in columns:
        raise PipelineError("CSVQA plan refers to an unknown column")
    actual, expected = row[column], condition.get("value")
    if operator == "eq": return actual == str(expected)
    if operator == "ne": return actual != str(expected)
    if operator == "in":
        if not isinstance(expected, list): raise PipelineError("CSVQA in condition needs a list")
        return actual in [str(value) for value in expected]
    if operator == "contains": return str(expected).casefold() in actual.casefold()
    if operator in {"gt", "ge", "lt", "le"}:
        try: left, right = float(actual), float(expected)
        except (ValueError, TypeError) as exc: raise PipelineError("CSVQA numeric condition has nonnumeric values") from exc
        return {"gt": left > right, "ge": left >= right, "lt": left < right, "le": left <= right}[operator]
    raise PipelineError("CSVQA plan uses an unsupported comparison")


def _extract(tables, plan):
    selections = plan.get("selections")
    if not isinstance(selections, list) or len(selections) != len(tables):
        raise PipelineError("CSVQA must account for every supplied table")
    by_name = {item.get("file"): item for item in selections if isinstance(item, dict)}
    if set(by_name) != {table["name"] for table in tables}:
        raise PipelineError("CSVQA table names do not match the supplied files")
    observations = []
    for table in tables:
        selection = by_name[table["name"]]
        conditions = selection.get("conditions", [])
        logic = selection.get("logic", "and")
        if not isinstance(conditions, list) or logic not in {"and", "or"}:
            raise PipelineError("CSVQA conditions are invalid")
        selected = []
        for index, row in enumerate(table["rows"]):
            matches = [_condition(row, condition, table["columns"]) for condition in conditions]
            if not matches or (all(matches) if logic == "and" else any(matches)):
                selected.append({"source_row": index, "values": row})
        record = {"file": table["name"], "source_rows": len(table["rows"]),
                  "selected_rows": len(selected), "columns": table["columns"], "records": selected,
                  "records_complete": True, "conditions": conditions, "logic": logic}
        if len(json.dumps(record, ensure_ascii=False)) > 28000:
            record.update(records=selected[:3] + selected[-2:], records_complete=False,
                          note="Illustrative first/last rows only. Read complete source CSV at runtime.")
        observations.append(record)
    return observations


def _prior_context(context):
    prior = context.get("prior_artifacts") or {}
    if not isinstance(prior, dict): return {}
    nested = prior.get("artifacts") if isinstance(prior.get("artifacts"), dict) else {}
    result = {}
    for key in ["query", "formulation", "model", "code", "execution", "answer"]:
        value = prior.get(key)
        if value is None or (key == "query" and prior.get("intent") in {"explain", "clarify"}):
            value = nested.get(key)
        if value is not None:
            result[key] = str(value)[:20000]
    return result


def run_pipeline(context, emit, execute, cancelled=lambda: False):
    """Generate and execute a real new model, or answer a contextual follow-up.

    execute(code, input_dir, output_dir=None, cancelled=None, kind='solve') is
    supplied by the API and must never execute generated programs on the host.
    """
    _check_cancel(cancelled)
    language = "en" if context.get("language") == "en" else "zh"
    tr = lambda zh, en: en if language == "en" else zh
    query = str(context.get("query", "")).strip()
    if not query: raise PipelineError("A question is required")
    try:
        provider = create_provider(context)
    except ProviderError as exc:
        raise PipelineError(str(exc)) from exc
    stage = "classification"
    def event(kind, payload):
        _check_cancel(cancelled)
        emit(stage, kind, payload)
    def chat(system, payload, *, structured=False, tokens=False):
        _check_cancel(cancelled)
        return provider.complete([
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ], json_mode=structured, cancelled=cancelled,
            on_token=(lambda text: event("token", {"text": text})) if tokens else None)
    result = {"intent": "solve", "query": query, "classification": None, "workflow": None,
              "data": None, "model": None, "code": None, "execution": None, "answer": "", "artifacts": {}}
    try:
        event("started", {"message": tr("理解当前问题与对话上下文", "Reading the task and conversation context")})
        messages = [{"role": m.get("role"), "content": str(m.get("content", ""))[:6000]}
                    for m in (context.get("messages") or [])[-12:] if isinstance(m, dict) and m.get("role") in {"user", "assistant"}]
        intent = _json(chat("""Resolve the current conversational request. Return JSON only:
{"intent":"solve|revise|explain|clarify","task":"standalone complete modeling task","question":"clarifying question if needed"}.
solve is a new complete optimization task; revise changes an existing task and must
preserve all unchanged earlier requirements in task. explain asks about an existing
model/code/result and must not run a new solver. clarify is only for material
missing information that prevents a formulation; do not ask to confirm a clear task.
Current files may resolve schema questions. Do not invent data or target solutions.
No hidden reasoning. Language: """ + language,
            {"query": query, "messages": messages, "files": [f["name"] for f in context.get("files", [])], "prior_artifacts": _prior_context(context)}, structured=True))
        action = intent.get("intent")
        if action not in {"solve", "revise", "explain", "clarify"}:
            raise PipelineError("The model returned an invalid conversation action")
        result["intent"] = action
        if action in {"explain", "clarify"}:
            event("completed", {"intent": action})
            stage = "output"
            event("started", {"message": tr("回答当前问题", "Answering the question")})
            if action == "clarify":
                result["answer"] = str(intent.get("question") or tr("请补充目标、决策变量和必要约束。", "Please specify the objective, decisions and required constraints."))
            else:
                result["answer"] = chat("Explain the supplied model/code/result in " + language +
                    ". Use only the recorded artifacts and conversation. Clearly distinguish a solver result from a guarantee of business correctness. Give a concise explanation, not a reasoning transcript. Do not invent a new objective or claim a new run.",
                    {"query": query, "messages": messages, "prior_artifacts": _prior_context(context)}, tokens=True)
            result["artifacts"] = _prior_context(context) or {"query": query}
            event("completed", {"answer": result["answer"], "intent": action})
            return result
        prior = _prior_context(context)
        rewritten = str(intent.get("task") or query).strip()
        # A model's intent/task rewrite is supporting context, never the sole
        # source of requirements. Preserve the literal latest request downstream.
        resolved = "CURRENT USER REQUEST (authoritative; apply every stated change):\n" + query
        if prior.get("query"):
            resolved += "\n\nPREVIOUS MODELING TASK (context; retain unchanged requirements for a follow-up):\n" + prior["query"]
        resolved += "\n\nASSISTANT TASK REWRITE (supporting only; never override or omit the current request):\n" + rewritten
        result["query"] = resolved
        tables = _load_tables(context.get("files", []))
        profiles = _profiles(tables)
        retriever = ReferenceRetriever(provider, cancelled)
        evidence = retriever.search(resolved, count=5)
        event("tool", {"name": "FileQA", "status": "completed",
                       "examples": [{"id": e["id"], "type": e["type"], "query": e["query"]} for e in evidence]})
        classification = _json(chat(CLASSIFICATION_SYSTEM,
            {"query": resolved, "FileQA": [{"type": e["type"], "query": e["query"]} for e in evidence]}, structured=True))
        label = classification.get("label")
        if label not in CLASSES: raise PipelineError("Classification did not return a supported problem type")
        route = "Others" if label in {"Others", "Mixture"} or not tables else label
        result["classification"] = {"label": label, "route": route}
        event("completed", result["classification"])

        stage = "workflow"
        event("started", {"message": tr("检索示例并构建建模工作流", "Retrieving demonstrations and assembling the workflow")})
        examples = retriever.search(resolved, route=route, count=3 if route == "Others" else 1)
        mode = "type-agnostic" if route == "Others" else "type-tailored"
        result["workflow"] = {"mode": mode, "route": route,
            "examples": [{"id": e["id"], "type": e["type"], "query": e["query"]} for e in examples],
            "steps": ["query", "schema", "indices", "variables", "parameters", "objective", "constraints"]}
        event("completed", result["workflow"])

        stage = "data"
        event("started", {"message": tr("读取真实 CSV 并检查数据选取", "Reading source CSVs and checking data selection")})
        warning = None
        observations = []
        if tables:
            try:
                plan = _json(chat("""You plan the CSVQA data tool. Return JSON only:
{"selections":[{"file":"exact supplied filename","logic":"and","conditions":[{"column":"exact column name","op":"eq|ne|in|contains|gt|ge|lt|le","value":"value or list"}]}]}.
Include each supplied table exactly once, preserving all columns. Use conditions=[]
when the query does not request a subset; never copy entity filters from examples.
Use exact identifiers; a zero-match filter must not be broadened. Blank column
names can be actual row identifiers in matrix exports. No Python, no SQL, no thoughts.""",
                    {"query": resolved, "tables": profiles}, structured=True))
                observations = _extract(tables, plan)
            except PipelineError:
                warning = "Invalid extraction plan; source tables are preserved without filtering. The current query controls runtime selection."
                observations = _extract(tables, {"selections": [{"file": t["name"], "conditions": []} for t in tables]})
        result["data"] = {"tables": profiles, "observations": observations, "warning": warning}
        event("tool", {"name": "CSVQA", "status": "completed", "tables": profiles,
                       "selected_rows": {o["file"]: o["selected_rows"] for o in observations}, "warning": warning})
        event("completed", result["data"])

        stage = "model"
        event("started", {"message": tr("生成数学模型或抽象建模计划", "Generating the formulation or abstract model plan")})
        workflow_note = ("Produce an Abstract Model Plan: analyze query; identify LP/MILP type; define index sets and variable domains; identify exact source columns, selected sets and joins; state objective and every constraint."
                         if mode == "type-agnostic" else
                         "Use the type-specific demonstration to produce sets, parameters, variable domains, objective and every constraint using the CURRENT CSVQA observation.")
        model = chat(MODEL_SYSTEM + "\n" + workflow_note,
            {"query": resolved, "latest_request": query, "prior_artifacts": prior,
             "workflow": result["workflow"], "reference_demonstrations":
             [{"query": e["query"], "formulation": e["formulation"]} for e in examples], "CSVQA": result["data"]})
        result["model"] = model
        event("artifact", {"kind": "formulation", "content": model})
        event("completed", {"formulation": model, "mode": mode})

        stage = "code"
        event("started", {"message": tr("生成读取完整源数据的求解程序", "Generating a program that reads complete source data")})
        code_context = {"query": resolved, "latest_request": query, "prior_artifacts": prior,
                        "formulation": model, "files": profiles,
                        "data_observations": observations,
                        "reference_examples": [{"query": e["query"], "formulation": e["formulation"], "code": e["code"]} for e in examples]}
        code = _code(chat(CODE_SYSTEM, code_context))
        repaired = False
        def repair(source, diagnostic):
            nonlocal repaired
            repaired = True
            event("tool", {"name": "code-repair", "status": "started", "message": tr("根据实际错误修复程序一次", "Repairing the program once using the actual diagnostic")})
            updated = _code(chat(CODE_SYSTEM + "\nRepair only the reported syntax/runtime error. Preserve all original modeling semantics, data selection, objective, variable domains and constraints. Return the complete program. Do not weaken constraints or invent data.",
                                 {**code_context, "previous_code": source, "diagnostic": diagnostic}))
            event("tool", {"name": "code-repair", "status": "completed"})
            return updated
        try:
            ast.parse(code)
        except SyntaxError as exc:
            code = repair(code, f"Python syntax error at line {exc.lineno}: {exc.msg}")
            try: ast.parse(code)
            except SyntaxError as second: raise PipelineError("Generated code still has a syntax error after one repair") from second
        result["code"] = code
        event("artifact", {"kind": "code", "content": code})
        event("completed", {"code": code})

        stage = "execution"
        event("started", {"message": tr("在隔离执行器中运行 Python / Gurobi", "Running Python / Gurobi in the isolated executor")})
        input_dir = context.get("input_dir")
        if not input_dir:
            parents = {str(Path(f["path"]).resolve().parent) for f in context.get("files", [])}
            if len(parents) != 1: raise PipelineError("The API must supply a per-run input directory")
            input_dir = parents.pop()
        _check_cancel(cancelled)
        execution = execute(code, str(input_dir), output_dir=context.get("output_dir"), cancelled=cancelled, kind="solve")
        _check_cancel(cancelled)
        if execution.get("status") == "error" and not repaired:
            stage = "code"
            code = repair(code, str(execution.get("error") or execution.get("stderr") or "Execution failed")[-8000:])
            try: ast.parse(code)
            except SyntaxError as exc: raise PipelineError("The repaired program has a syntax error") from exc
            result["code"] = code
            event("artifact", {"kind": "code", "content": code})
            stage = "execution"
            execution = execute(code, str(input_dir), output_dir=context.get("output_dir"), cancelled=cancelled, kind="solve")
            _check_cancel(cancelled)
        result["execution"] = execution
        event("completed", execution)
        stage = "output"
        status = execution.get("status", "error")
        descriptions = {
            "optimal": tr("已求得最优解。", "An optimal solution was found."),
            "infeasible": tr("求解器报告模型不可行；请检查需求、容量及其他约束。", "The solver reports infeasibility; inspect demand, capacity and the other constraints."),
            "unbounded": tr("求解器报告模型无界。", "The solver reports an unbounded model."),
            "time_limit": tr("求解达到时间上限；当前结果不应称为已证最优。", "The solve reached its time limit; do not describe the incumbent as proven optimal."),
            "solver_stopped": tr("求解器已停止，尚未证得最优解；请查看求解状态码。", "The solver stopped without proving optimality; inspect the solver status code."),
            "execution_unavailable": tr("数学模型与代码已生成；隔离执行环境当前不可用，尚未求解。", "The formulation and code are ready; isolated execution is unavailable, so no solve was performed."),
            "cancelled": tr("运行已取消。", "The run was cancelled."),
        }
        result["answer"] = descriptions.get(status, tr("程序执行失败；已保留模型、代码与错误诊断。", "Execution failed; the formulation, code and diagnostic are retained."))
        if status == "solver_stopped" and execution.get("solver_status_code") is not None:
            result["answer"] += tr(" 状态码：", " Status code: ") + str(execution["solver_status_code"])
        if execution.get("objective") is not None:
            result["answer"] += tr(" 目标值：", " Objective: ") + str(execution["objective"])
        result["artifacts"] = {"query": resolved, "formulation": model, "code": code, "execution": execution}
        event("artifact", {"kind": "result", "content": result["artifacts"]})
        event("completed", {"answer": result["answer"], "artifacts": result["artifacts"]})
        return result
    except ProviderError as exc:
        _check_cancel(cancelled)
        emit(stage, "error", {"message": str(exc)})
        raise PipelineError(str(exc)) from exc
    except PipelineCancelled:
        raise
    except PipelineError as exc:
        emit(stage, "error", {"message": str(exc)})
        raise
    finally:
        provider.close()
