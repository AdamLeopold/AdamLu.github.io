"""Read-only discovery of the visitor's fixed loopback Ollama service."""
from __future__ import annotations

import httpx


OLLAMA_TAGS_URL = "http://127.0.0.1:11434/api/tags"
CHAT_MODEL = "gpt-oss:20b"
EMBEDDING_MODEL = "nomic-embed-text"


def ollama_status() -> dict:
    """List installed models without loading one or starting a solver worker."""
    status = {
        "reachable": False,
        "ready": False,
        "missing_models": [CHAT_MODEL, EMBEDDING_MODEL],
        "chat_model": CHAT_MODEL,
        "embedding_model": EMBEDDING_MODEL,
    }
    try:
        with httpx.Client(timeout=httpx.Timeout(2.0), trust_env=False, follow_redirects=False) as client:
            response = client.get(OLLAMA_TAGS_URL)
            response.raise_for_status()
            data = response.json()
        if not isinstance(data, dict) or not isinstance(data.get("models"), list):
            return status
        names = {
            item.get("name") or item.get("model")
            for item in data["models"] if isinstance(item, dict)
            and isinstance(item.get("name") or item.get("model"), str)
        }
        missing = [model for model in (CHAT_MODEL, EMBEDDING_MODEL)
                   if model not in names and not (":" not in model and model + ":latest" in names)]
        return {**status, "reachable": True, "ready": not missing, "missing_models": missing}
    except (httpx.HTTPError, ValueError, TypeError):
        return status
