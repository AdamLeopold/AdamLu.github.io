"""Shared bounds for CSV parsing and retained table records."""
from dataclasses import dataclass

MAX_CSV_ROWS = 100_000
MAX_CSV_CELLS = 1_000_000
MAX_CSV_COLUMNS = 1_000


class CSVLimitError(ValueError):
    pass


@dataclass
class CSVBudget:
    rows: int = 0
    cells: int = 0

    def add(self, rows, cells):
        if self.rows + rows > MAX_CSV_ROWS or self.cells + cells > MAX_CSV_CELLS:
            raise CSVLimitError(
                f"CSV tables may contain at most {MAX_CSV_ROWS} data rows and "
                f"{MAX_CSV_CELLS} cells in total")
        self.rows += rows
        self.cells += cells

    def header(self, columns):
        if not 0 < columns <= MAX_CSV_COLUMNS:
            raise CSVLimitError(f"Each CSV may contain at most {MAX_CSV_COLUMNS} columns")
        self.add(0, columns)

    def row(self, columns):
        self.add(1, columns)

    def table(self, rows, columns):
        self.header(columns)
        self.add(rows, rows * columns)


def check_csv_metadata(files):
    budget = CSVBudget()
    for metadata in files:
        budget.table(metadata["row_count"], len(metadata["columns"]))
