"""Explicit local/cloud deployment contract; no inferred public service mode."""
from dataclasses import dataclass
import os
import re
from urllib.parse import urlsplit


@dataclass(frozen=True)
class CloudLimits:
    sessions: int = 40
    sessions_per_owner: int = 6
    session_ttl: int = 6 * 60 * 60
    runs: int = 32
    runs_per_session: int = 8
    waiting_runs: int = 4
    session_bytes: int = 256 * 1024 * 1024
    total_bytes: int = 1024 * 1024 * 1024
    event_count: int = 1024
    event_bytes: int = 4 * 1024 * 1024
    result_bytes: int = 8 * 1024 * 1024
    sse_per_owner: int = 2
    sse_total: int = 40
    sse_seconds: int = 5 * 60
    request_seconds: int = 60
    requests_per_minute: int = 240
    writes_per_minute: int = 30


@dataclass(frozen=True)
class DeploymentConfig:
    mode: str = "local"
    public_origin: str = ""
    trusted_proxies: tuple[str, ...] = ("127.0.0.1",)
    limits: CloudLimits = CloudLimits()

    def __post_init__(self):
        if self.mode not in {"local", "cloud"}:
            raise ValueError("LEAN_DEMO_MODE must be local or cloud")
        if not self.trusted_proxies or any(ip not in {"127.0.0.1", "::1"} for ip in self.trusted_proxies):
            raise ValueError("Trusted proxy addresses must be explicit loopback IPs")
        if self.mode == "cloud":
            parsed = urlsplit(self.public_origin)
            # One canonical HTTPS hostname, optionally with a nondefault port.
            if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
                    or parsed.path or parsed.query or parsed.fragment
                    or not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::[0-9]{1,5})?", parsed.netloc)
                    or "." not in parsed.hostname or ".." in parsed.hostname
                    or parsed.hostname.endswith(".localhost")
                    or re.fullmatch(r"[0-9.]+", parsed.hostname)):
                raise ValueError("Cloud mode requires LEAN_DEMO_PUBLIC_ORIGIN=https://one-public-hostname")
            try:
                if parsed.port is not None and not 0 < parsed.port <= 65535:
                    raise ValueError()
            except ValueError:
                raise ValueError("Invalid public origin port") from None
        elif self.public_origin:
            raise ValueError("LEAN_DEMO_PUBLIC_ORIGIN requires cloud mode")

    @property
    def cloud(self):
        return self.mode == "cloud"

    @property
    def authority(self):
        return urlsplit(self.public_origin).netloc

    @classmethod
    def from_env(cls):
        return cls(mode=os.environ.get("LEAN_DEMO_MODE", "local"),
                   public_origin=os.environ.get("LEAN_DEMO_PUBLIC_ORIGIN", ""),
                   trusted_proxies=tuple(os.environ.get("LEAN_DEMO_TRUSTED_PROXIES", "127.0.0.1").split(",")))
