import os
import uvicorn
from .api import create_app

if __name__ == "__main__":
    app = create_app()
    config = app.state.deployment
    # A same-host HTTPS proxy is the only public ingress. Never accept arbitrary
    # forwarded headers or expose the host's Docker-capable API directly.
    uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("LEAN_DEMO_PORT", "8097")),
                access_log=False, proxy_headers=config.cloud,
                forwarded_allow_ips=",".join(config.trusted_proxies) if config.cloud else "",
                limit_concurrency=64 if config.cloud else None, timeout_keep_alive=5)
