import os
import uvicorn
from .api import create_app

if __name__ == "__main__":
    uvicorn.run(create_app(), host="127.0.0.1", port=int(os.environ.get("LEAN_DEMO_PORT", "8097")), access_log=False)
