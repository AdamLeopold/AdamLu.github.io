# LEAN-LLM-OPT 本地工作台

这个下载包在你的电脑运行独立建模工作台。公开网页只提供示例与入口；Ollama 模型、上传的 CSV、生成程序和求解任务由你的本机服务处理。

## 准备

1. 安装 Python 3.10 或更新版本、Ollama 和 Docker Desktop（Linux 可使用 Docker Engine）。
2. 在终端准备生成模型与检索模型：

   ```sh
   ollama pull gpt-oss:20b
   ollama pull nomic-embed-text
   ```

   保持 Ollama 运行；如果尚未启动，可在另一个终端运行 `ollama serve`。使用默认本机地址即可，无需开放网络监听或修改跨域配置。模型下载需要网络与足够的磁盘、内存空间；首次运行可能较慢。
3. 完整 Python/Gurobi 求解需要运行中的 Docker，以及你有权使用的 Gurobi 12.0.1 许可证。在启动工作台的同一终端，将 `GRB_LICENSE_FILE` 指向你的许可证文件；未指定时使用主目录中的 `gurobi.lic`。使用 WLS 时需能连接 Gurobi 许可服务。下载包不包含许可证。

## 启动

解压后，在包含本 README 的目录打开终端：

```sh
python3 scripts/run_demo.py --open
```

Windows 使用：

```powershell
python scripts/run_demo.py --open
```

启动脚本会创建 `.venv-demo`、安装必要的 Python 包，并在 Docker 可用时构建求解镜像。首次安装需要网络。工作台地址为 **http://127.0.0.1:8097/demo/**；服务仅监听本机。保留终端运行，按 `Ctrl+C` 关闭。可省略 `--open` 后手动打开地址。

在公开网页选择示例后，打开本机工作台并确认运行。检查连接只读取 Ollama 已安装模型列表；“检查求解器”会启动隔离求解环境。浏览器重开页面不会自动提交 URL 中的运行请求。没有 Docker 或许可证时仍可生成模型与代码，运行结果会标明未求解。

这是当前电脑的本地服务：手机上的 `127.0.0.1` 指手机，不会连接另一台电脑。工作台重启后会清除临时会话；需要保留的模型、代码和结果请下载。

[研究主页](https://adamleopold.github.io/AdamLu.github.io/lean-llm-opt/) · [Ollama](https://ollama.com/download) · [Gurobi](https://www.gurobi.com/)

---

# LEAN-LLM-OPT local workspace

This package runs the modeling workspace on your computer. The public website provides examples and a launch link; your local companion handles Ollama, uploaded CSVs, generated programs, and optimization runs.

## Prerequisites

1. Install Python 3.10 or later, Ollama, and Docker Desktop (or Docker Engine on Linux).
2. Download the generation and retrieval models in a terminal:

   ```sh
   ollama pull gpt-oss:20b
   ollama pull nomic-embed-text
   ```

   Keep Ollama running. If needed, start `ollama serve` in another terminal. Its default loopback address is sufficient; no network exposure or CORS configuration is required. Model downloads need internet access and sufficient disk space and memory. The first run may take longer.
3. Python/Gurobi execution requires Docker and a Gurobi 12.0.1 license that you are authorized to use. In the same terminal that starts the workspace, set `GRB_LICENSE_FILE` to your license file; otherwise the companion looks for `gurobi.lic` in your home directory. WLS requires access to Gurobi's licensing service. No license is included in this package.

## Start

Extract the archive and open a terminal in the directory containing this README:

```sh
python3 scripts/run_demo.py --open
```

On Windows:

```powershell
python scripts/run_demo.py --open
```

The launcher creates `.venv-demo`, installs the Python dependencies, and builds the isolated solver image when Docker is available. Initial setup requires internet access. The workspace opens at **http://127.0.0.1:8097/demo/** and listens on loopback only. Keep the terminal running; press `Ctrl+C` to stop. Omit `--open` to open the address manually.

Choose an example on the public website, open the local workspace, and confirm the run. Connection checks only list installed Ollama models; “Check solver” starts the isolated solver environment. Reopening a page does not automatically execute a request from its URL. Without Docker or a license, formulation and code generation remain available and the result is marked as not solved.

This service runs on the current device: `127.0.0.1` on a phone refers to that phone, not another computer. Sessions are temporary and cleared when the workspace restarts. Download any models, code, and results you want to keep.

[Research home](https://adamleopold.github.io/AdamLu.github.io/lean-llm-opt/) · [Ollama](https://ollama.com/download) · [Gurobi](https://www.gurobi.com/)
